sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	'sap/ui/core/Core',
	"sap/ui/core/message/Message",
	"sap/m/library",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",	
	"sap/base/util/deepExtend",
	'sap/ui/core/Element'
], function(BaseController, JSONModel, formatter, MessagePopover, MessageItem, Core,  Message, mobileLibrary, Filter, FilterOperator, deepExtend, Element) {
	"use strict";

	// var controller, component;
	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;

	return BaseController.extend("lmco.ces.preq.controller.Detail", {

		formatter: formatter,

		onInit : function () {

			// if(!controller) 
			// controller = this;

			// component = this.getOwnerComponent();

			// this.oView = this.getView();

			// this.oRouter = this.getOwnerComponent().getRouter();

			// this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// this.setModel(oViewModel, "detailView");

			// this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},


		onExit: function(oEvent){
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		// onSendEmailPress : function () {
		// 	var oViewModel = this.getModel("detailView");

		// 	URLHelper.triggerEmail(
		// 		null,
		// 		oViewModel.getProperty("/shareSendEmailSubject"),
		// 		oViewModel.getProperty("/shareSendEmailMessage")
		// 	);
		// },


		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished : function (oEvent) {
			var sTitle,
				fOrderTotal = 0,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView"),
				oItemsBinding = oEvent.getSource().getBinding("items"),
				aItemsContext;

			// only update the counter if the length is final
			if (oItemsBinding.isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);

				aItemsContext = oItemsBinding.getContexts();
				fOrderTotal = aItemsContext.reduce(_calculateOrderTotal, 0);
				oViewModel.setProperty("/totalOrderAmount", fOrderTotal);
			}

		},

		onCreateNewReqItem: function(oEvent){
			let _head = this.getView().getBindingContext().getObject();
			let _user = this.getUser();
			let _newData = {};
			let _cTab = this.getView().byId('lineItemsList');
			let oItemsBinding = _cTab.getBinding("rows");
			let _self = this;
			let _nextItem = 0;

			var padWithLeadingZeros=function(num, totalLength) {
				return String(num).padStart(totalLength, '0');
			}
			_cTab.getBinding('rows').getContexts().forEach((rr) => {
				_nextItem = Math.max(_nextItem,parseInt(rr.getObject().PrqItem))
			})

			// call Function Import to generate New blank row
			_newData.PrqNo = _head.PrqNo;
			_newData.CName = _user.getId();
			_newData.bMaterial = false;
			// _newData.ItemType = 'P';
			// _newData.ItemTypeText = 'Product';
			_newData.Menge = "0.0";
			_newData.Preis = "0.0";
			_newData.Curr = 'USD';
			_newData.bEkgrpUseDef = (!!_head.PurchGrp)?true:false;

			if(!!_newData.bEkgrpUseDef) {
				_newData.Ekgrp = _head.PurchGrp;
				_newData.Eknam = _head.PurchGrpName;
			}
			
			// _newData.Meins = 'EA';
			_newData.bNewMaterial = false;
			_newData.bSoftware = false;
			_newData.bEditable = true;
			_newData.PrqItem = padWithLeadingZeros(_nextItem+1, 3);

			_newData.bSplit = false;
			_newData.bWBS = false;
			_newData.bCC = false;
			_newData.bGL = false;
			_newData.bHazmat= false;
			_newData.bForeign = false;
			_newData.bInspect= false;
			_newData.bInvApprUseDef= true;
			_newData.bPostApprove = true;
			// _newData.bEkgrpUseDef= true;

			_newData.bApprove = false;


			oItemsBinding.create(_newData, true, {inactive : false})


		},

		onItemDetail: function(oEvent){
			let _self = this;

			var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
				__path = oEvent.oSource.getBindingContext().getPath(),
				__item = oEvent.oSource.getBindingContext().getObject();
				// supplier = __path.split("/").slice(-1).pop();
	
			this.getModel("appView").setProperty("/layout", oNextUIState.layout);
			this.getModel("appView").setProperty("/itemView", true);
	
			this.getOwnerComponent().setModel(new JSONModel(__item),'item');
	
			this.getOwnerComponent().getRouter().navTo("objectItem", {
				objectId: __item.PrqNo, 
				itemId: __item.PrqItem
			});
	
		
		},

		onItemSelect: function(oEvent){

		if(oEvent.oSource.getSelectionMode()==='Single'){
			var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
			__path = oEvent.oSource.getBindingContext().getPath(),
			__item =oEvent.getParameter('rowContext').getObject();
			// supplier = __path.split("/").slice(-1).pop();

		this.getModel("appView").setProperty("/layout", oNextUIState.layout);
		this.getModel("appView").setProperty("/itemView", true);

		this.getOwnerComponent().setModel(new JSONModel(__item),'item');

		this.oRouter.navTo("objectItem", {
			objectId: __item.PrqNo, 
			itemId: __item.PrqItem
		});


		}
		},

		handlePiPDateChange(oEvent){
			let _ctx = oEvent.oSource.getBindingContext(),
				_mdl = _ctx.oModel,
				_sp  = _ctx.sPath;

			let _from = new Date(oEvent.getParameter('from')).YYYYMMDD(),
				_to = new Date(oEvent.getParameter('to')).YYYYMMDD();

			_mdl.setProperty(_sp+'/PipStart',_from);
			_mdl.setProperty(_sp+'/PipEnd',_to);

			_mdl.refresh(true);

		},

		onSaveItems: function(oEvent){
			let _mdl = this.getModel();

			if(_mdl.hasPendingChanges()) {
				_mdl.submitChanges({
					success: function(oData){
						_mdl.refresh(true);
					},
					error: function(oError){
						let _msg = JSON.parse(oError.responseText);
						sap.m.MessageBox.error(_msg.error.message.value);	
					}
				})
			}

		},

		onChargeCodeSuggest: function (oEvent) {
			let _user = this.getUser();
			let _mdl = oEvent.oSource.getBindingContext().oModel,
				_prq = oEvent.oSource.getBindingContext().getObject(),
				_key = _mdl.createKey('/HeaderSet',{'PrqNo':_prq.PrqNo, 'Userid': _user.getId()}),
				_pl = _mdl.getProperty(_key+'/Plant');

			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("ZlDesc", FilterOperator.StartsWith, sTerm));
				aFilters.push(new Filter("ZlSite", FilterOperator.EQ, _pl));
				aFilters.push(new Filter("ZlSrc", FilterOperator.EQ, 'CC'));
			}

			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
		},



		onChargeCodeChange: function(oEvent){
			let _user = this.getUser();
			let _ctx = oEvent.oSource.getBindingContext(),
				_self = this,
				_sp = _ctx.sPath,
				_val = oEvent.oSource.getValue(),
				_prq = oEvent.oSource.getBindingContext().getObject(),
				_mdl = _ctx.oModel,
				_key = _mdl.createKey('/HeaderSet',{'PrqNo':_prq.PrqNo, 'Userid':_user.getId()}),
				_pl = _mdl.getProperty(_key+'/Plant');


			let _mKey = _mdl.createKey('/ChargeCodeSet',{
				ZlFrom: _val,
				ZlSite: _pl
			})

			_mdl.read(_mKey,{
				success: function(oData){
					if(!!oData.ZlFrom){
						_mdl.setProperty(_sp+'/ChargeNum',oData.ZlFrom);
						// _mdl.setProperty(_sp+'/Contract',oData.ZlPrimCont);
					} else {
						_mdl.setProperty(_sp+'/ChargeNum','');
						// _mdl.setProperty(_sp+'/Contract','');
					}
				},

				error: function(oData){
					_mdl.setProperty(_sp+'/ChargeNum','');
					// _mdl.setProperty(_sp+'/Contract','');
				}
			})


		},

		onItemCopy: function(oEvent){
			let _self = this;
			let _key = oEvent.oSource.getBindingContext().sPath;
			let _obj = oEvent.oSource.getBindingContext().getObject();
			let _newData = {};
			let _cTab = this.getView().byId('lineItemsList');
			let oItemsBinding = _cTab.getBinding("rows");
			let _nextItem = 0;

			var padWithLeadingZeros=function(num, totalLength) {
				return String(num).padStart(totalLength, '0');
			}

			_cTab.getBinding('rows').getContexts().forEach((rr) => {
				_nextItem = Math.max(_nextItem,parseInt(rr.getObject().PrqItem))
			})

			Object.keys(_obj).forEach((_k) => { 
				_newData[_k] = (_obj[_k] instanceof Date)? _obj[_k].YYYYMMDD() :_obj[_k];
			})

			_newData.PrqItem = padWithLeadingZeros(_nextItem+1, 3);
			if(_newData.bSplit){
				_newData.Category = '';
				_newData.CostCenter = '';
				_newData.GLAcc = '';
				_newData.bSplit = false;
				_newData.bWBS = false;
				_newData.bCC = false;	
			}
			_newData.aName = '';
			_newData.aDate = '';
			_newData.aNote = '';
			_newData.aSmtp = '';
			_newData.aStatus = '';
			_newData.aTime = '';
			_newData.aUser = '';

			oItemsBinding.create(_newData, true, {inactive : false})

			// oEvent.oSource.getModel().remove(_key, {
			// 	success: function(oData){
			// 		_self.getModel().refresh(true);
			// 	},
			// 	error: function(oError, oResponse){
			// 		let _msg = JSON.parse(oError.responseText);
			// 		sap.m.MessageBox.error(_msg.error.message.value);
			// 	}
			// })

		},

		onItemDelete: function(oEvent){
			let _self = this;
			let _key = oEvent.oSource.getBindingContext().sPath;
			let _model = oEvent.oSource.getModel();

			let _cc = Object.keys(_model.getPendingChanges()).find((a) => { return '/'+a===_key})

			if(!!_cc) {
				_model.resetChanges([_key], true, true)
				.then(function(oRet){
					_self.getModel().refresh(true);
				})
			} else {
				oEvent.oSource.getModel().remove(_key, {
					success: function(oData){
						_self.getModel().refresh(true);
					},
					error: function(oError, oResponse){
						let _msg = JSON.parse(oError.responseText);
						sap.m.MessageBox.error(_msg.error.message.value);
					}
				})	
			}

		},

		onChargeCodeSelected: function(oEvent){

		},

		onOptionsChange: function(oEvent){

			let _mdl = oEvent.oSource.getModel(),
				_sPath = oEvent.oSource.getBindingContext().sPath,
				_data = oEvent.oSource.getBindingContext().getObject();
	
			if(!_data.bMaterial) {
				// _mdl.setProperty(_sPath+'/bOverLimit',false);
				_mdl.setProperty(_sPath+'/bDeliverable',false);
				_mdl.setProperty(_sPath+'/bLMuse',false);
			}
	
			// if(!_data.bOverLimit) {
			// 	_mdl.setProperty(_sPath+'/bDeliverable',false);
			// 	_mdl.setProperty(_sPath+'/bLMuse',false);
			// }
	
			if(!_data.bDeliverable) {
				_mdl.setProperty(_sPath+'/bLMuse',false);
			}
	
		},
	

		// _bindView : function (sObjectPath) {
		// 	// Set busy indicator during view binding
		// 	var oViewModel = this.getModel("detailView");

		// 	// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
		// 	oViewModel.setProperty("/busy", false);

		// 	this.getView().bindElement({
		// 		path : sObjectPath,
		// 		// parameters: {
		// 		// 	expand: "Customer,Order_Details/Product,Employee"
		// 		// },
		// 		events: {
		// 			change : this._onBindingChange.bind(this),
		// 			dataRequested : function () {
		// 				oViewModel.setProperty("/busy", true);
		// 			},
		// 			dataReceived: function () {
		// 				oViewModel.setProperty("/busy", false);
		// 			}
		// 		}
		// 	});
		// },

		deleteSelectedItems: function(oEvent){
			let _selInd = this.byId("lineItemsList").getSelectedIndices();
			let _self = this;
			let _mdl = this.getModel();

			let _rows = [];

			this.byId("lineItemsList").getSelectedIndices().forEach((ii)=>{
				if(_self.byId("lineItemsList").getContextByIndex(ii)){
					_rows.push(_self.byId("lineItemsList").getContextByIndex(ii).getObject());
				}			
			})

			this.deleteItems({Data:_rows})
				.done(function(oData){
					_mdl.refresh(true);
				})
		},

		deleteItems: function (param, oContext) {
			var _p = param || {};
			var _self = this;
			let _mdl = this.getModel();
			var _promise = _p.Promise || $.Deferred();
			var _data = (_p)?_p.Data||{}:{};
			let _user = this.getUser();

			var f_delete = function(oItem,oPromise){
				let _pp = oPromise || $.Deferred();

				var key = _mdl.createKey("/ItemSet", {
					"PrqNo": oItem.PrqNo,
					"PrqItem": oItem.PrqItem,
					"CName" : _user.getId()
				});

				_mdl.remove(key,
					{
						success: function (data) {
							_pp.resolve(data);
						},
						error: function (error) {
							_pp.reject(error);
						}
					}
				);

				return _pp;
			};

			var _delWIUser = [];

			_data.forEach(function(oItem){
				var _p = $.Deferred();
				_delWIUser.push(f_delete(oItem,_p));
			})

			$.when.apply($, _delWIUser).then(function (data) {
				_promise.resolve(data);
			})

			return _promise;
		},

		// _onBindingChange : function () {
		// 	var oView = this.getView(),
		// 		oElementBinding = oView.getElementBinding();

		// 	// No data for the binding
		// 	if (!oElementBinding.getBoundContext()) {
		// 		this.getRouter().getTargets().display("detailObjectNotFound");
		// 		// if object could not be found, the selection in the master list
		// 		// does not make sense anymore.
		// 		this.getOwnerComponent().oListSelector.clearMasterListSelection();
		// 		return;
		// 	}

		// 	var sPath = oElementBinding.getPath(),
		// 		oResourceBundle = this.getResourceBundle(),
		// 		oObject = oView.getModel().getObject(sPath),
		// 		sObjectId = oObject.PrqNo,
		// 		sObjectName = oObject.PrqNo,
		// 		oViewModel = this.getModel("detailView");

		// 	this.getOwnerComponent().oListSelector.selectAListItem(sPath);

		// 	// oViewModel.setProperty("/shareSendEmailSubject",
		// 	// 	oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
		// 	// oViewModel.setProperty("/shareSendEmailMessage",
		// 	// 	oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href, oObject.ShipName, oObject.EmployeeID, oObject.CustomerID]));
		// },

		// _onMetadataLoaded : function () {
		// 	// Store original busy indicator delay for the detail view
		// 	var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
		// 		oViewModel = this.getModel("detailView");
		// 		// oLineItemTable = this.byId("lineItemsList"),
		// 		// iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

		// 	// Make sure busy indicator is displayed immediately when
		// 	// detail view is displayed for the first time
		// 	oViewModel.setProperty("/delay", 0);
		// 	oViewModel.setProperty("/lineItemTableDelay", 0);

		// 	// oLineItemTable.attachEventOnce("updateFinished", function() {
		// 	// 	// Restore original busy indicator delay for line item table
		// 	// 	oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
		// 	// });

		// 	// Binding the view will set it to not busy - so the view is always busy if it is not bound
		// 	oViewModel.setProperty("/busy", true);
		// 	// Restore original busy indicator delay for the detail view
		// 	oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		// },
		// onTabSelect : function(oEvent){
		// 	var sSelectedTab = oEvent.getParameter("selectedKey");

		// 	if(this._aValidKeys.indexOf(sSelectedTab) >= 0) {
		// 		this.getRouter().navTo("object", {
		// 			objectId: this._sObjectId,
		// 			query: {
		// 				tab: sSelectedTab
		// 			}
		// 		}, true);// true without history
	
		// 	}


		// },

		handleItemPress: function (oEvent) {
			var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
				__path = oEvent.oSource.getBindingContext().getPath(),
				__item = oEvent.getParameter('listItem').getBindingContext().getObject();
				// supplier = __path.split("/").slice(-1).pop();

			this.getModel("appView").setProperty("/layout", oNextUIState.layout);

			this.getOwnerComponent().setModel(new JSONModel(__item),'item');

			this.oRouter.navTo("objectItem", {
				objectId: __item.PrqNo, 
				itemId: __item.PrqItem
			});
		},



		enableItemMutiSelection: function (oEvent) {
			let _mdl = this.getModel('detailView');
			let _mode = _mdl.getProperty('/selMode');

			if (sap.ui.table.SelectionMode.None === _mode) {
			// if (sap.ui.table.SelectionMode.Single === this.byId("lineItemsList").getSelectionMode()) {
				this._doCloseItemDetail();
				_mdl.setProperty('/selMode',sap.ui.table.SelectionMode.MultiToggle);
				_mdl.setProperty('/itemDelMode',true);
				// this.byId("lineItemsList").setSelectionMode(sap.ui.table.SelectionMode.MultiToggle);
				// this.byId("__itemMultiDelete").setVisible(true);
			} else {
				_mdl.setProperty('/selMode',sap.ui.table.SelectionMode.None);
				_mdl.setProperty('/itemDelMode',false);
				// this.byId("lineItemsList").setSelectionMode(sap.ui.table.SelectionMode.Single);
				// this.byId("__itemMultiDelete").setVisible(false);
			}
			_mdl.refresh(true);
		},

		disableItemMutiSelection: function (oEvent) {
			let _mdl = this.getModel('detailView');

			_mdl.setProperty('/selMode',sap.ui.table.SelectionMode.None);
			_mdl.setProperty('/itemDelMode',false);

			_mdl.refresh(true);

			// this.byId("lineItemsList").setSelectionMode(sap.ui.table.SelectionMode.Single);
			// this.byId("__itemMultiDelete").setVisible(false);
		},

		onAfterRendering: function(oEvent){
		},

		onBeforeMenuOpen: function(oEvent){

		},
	});
});