sap.ui.define([
	"sap/m/library",
	"./BaseController",
	"../model/formatter",
	"sap/ui/core/Item",
	"sap/ui/model/json/JSONModel",
	"sap/m/upload/Uploader",
	"sap/m/StandardListItem",
	"sap/m/MessageToast"
], function (MobileLibrary, Controller, formatter, Item, JSONModel, Uploader, ListItem, MessageToast) {
	"use strict";

	var ListMode = MobileLibrary.ListMode;

	// var CustomUploader = Uploader.extend("lmco.ces.preq.CustomUploader", {
	// 	metadata: {}
	// });


	
	// CustomUploader.prototype.uploadItem = function (oItem, aHeaders) {
	// 	let _ctx = this.getBindingContext().getObject();
	// 	var sNewUploadUrl = "/sap/opu/odata/sap/Z_CES_PREQ_SRV/AttachmentSet"; // This value may be result of a backend request eg.
	// 	aHeaders.push(new Item({key: "prrnr", text: _ctx.PrqNo}));
	// 	aHeaders.push(new Item({key: "slug", text: oItem.getProperty('fileName')}));
	// 	this.setUploadUrl(sNewUploadUrl);

	// 	Uploader.prototype.uploadItem.call(this, oItem, aHeaders);
	// };

	// CustomUploader.prototype.downloadItem = function (oItem, aHeaders, bAskForLocation) {
	// 	var sNewDownloadUrl = oItem.getUrl(); // This value may be result of a backend request eg.
	// 	aHeaders.push(new Item({key: "SomeGetKey", text: "SomeGetText"}));
	// 	this.setDownloadUrl(sNewDownloadUrl);

	// 	Uploader.prototype.downloadItem.call(this, oItem, aHeaders, bAskForLocation);
	// };

	
	return Controller.extend("lmco.ces.preq.controller.Attachment", {
		formatter: formatter,		
		onInit: function () {
			// var 
				// sPath = sap.ui.require.toUrl("sap/m/sample/UploadSetCustomUploader/items.json"),
				// oUploadSet = this.byId("__preqAttach"),
				// oCustomUploader = new CustomUploader();

			// this.getView().setModel(new JSONModel(sPath));

			// oUploadSet.setUploader(oCustomUploader);
			// oUploadSet.registerUploaderEvents(oCustomUploader);

			// oUploadSet.addHeaderField(new sap.ui.core.Item({key: "x-csrf-token", text: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']}))

			// // Attach separate set of event handlers to demonstrate custom progress monitoring
			// oCustomUploader.attachUploadStarted(this.onUploadStarted.bind(this));
			// oCustomUploader.attachUploadProgressed(this.onUploadProgressed.bind(this));
			// oCustomUploader.attachUploadCompleted(this.onUploadCompleted.bind(this));
			// oCustomUploader.attachUploadAborted(this.onUploadAborted.bind(this));

			// oUploadSet.getList().setMode(ListMode.None);
		},
		handleUploadPress: function(oEvent) {
			var oContext = oEvent.oSource.getBindingContext(),
				_self = this,
				_ctx = oContext.getObject();
			let _user = this.getUser();				
			var oFileUploader = sap.ui.getCore().byId('__fileUploader'),
				oTitle = sap.ui.getCore().byId('__uplTitle');

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({name: "x-csrf-token", value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']}));
	
			if (!oFileUploader.getValue()) {
				MessageToast.show("Choose a file first");
				return;
			}
			oFileUploader.checkFileReadable().then(function() {
				_self.getView().setBusy(true);

				oFileUploader.insertHeaderParameter(new sap.ui.unified.FileUploaderParameter({name: "slug", value: oFileUploader.getValue() }));
				oFileUploader.insertHeaderParameter(new sap.ui.unified.FileUploaderParameter({name: "prrnr", value:_ctx.PrqNo }));
				oFileUploader.insertHeaderParameter(new sap.ui.unified.FileUploaderParameter({name: "title", value: oTitle.getValue() }));
				oFileUploader.insertHeaderParameter(new sap.ui.unified.FileUploaderParameter({name: "user", value: _user.getId() }));
		
				oFileUploader.upload();
			}, function(error) {
				MessageToast.show("The file cannot be read. It may have changed.");
			}).then(function() {
				oFileUploader.clear();
			});
		},

		handleDeleteAttachment: function(oEvent){
			let _mdl = oEvent.oSource.getBindingContext().oModel;
			let _list = oEvent.getSource(),
				_item = oEvent.getParameter("listItem"),
				_sPath = _item.getBindingContext().getPath();
			
			_list.attachEventOnce("updateFinished", _list.focus, _list);

			_mdl.remove(_sPath);
		},

		onNewUploadPress: function(oEvent){

			this._newUplDlg = sap.ui.xmlfragment("lmco.ces.preq.view.fragments.Upload", this)

			this.getView().addDependent(this._newUplDlg);
			// this._newUplDlg.setModel(_mdl,'mHdr');
			this._newUplDlg.open();

		},
		handleCancelUpload: function(oEvent){
			this.closeDialog(this._newUplDlg);
			// if(this._newUplDlg){
			// 	this._newUplDlg.close();
			// 	this._newUplDlg.destroy();				
			// 	this._newUPlDlg = null;
			// }
		},


		handleUploadComplete: function(oEvent) {
			var _self = this;
			this.closeDialog(this._newUplDlg);
			sap.m.MessageToast.show("File Uploaded");
			this.getModel().refresh(true);
	
			//_control.setEnabled(true);
			_self.getView().setBusy(false);
		},
	
		// onUploadStarted: function (oEvent) {
		// 	var oList = this.byId("progressList"),
		// 		oItem = oEvent.getParameter("item");
		// 	oList.insertItem(new ListItem({
		// 		title: "Upload started: " + oItem.getFileName()
		// 	}));
		// },
		// onUploadProgressed: function (oEvent) {
		// 	var oList = this.byId("progressList"),
		// 		oItem = oEvent.getParameter("item");
		// 	oList.insertItem(new ListItem({
		// 		title: "Upload progressed: " + oItem.getFileName()
		// 	}));
		// },
		// onUploadCompleted: function (oEvent) {
		// 	var oList = this.byId("progressList"),
		// 		oItem = oEvent.getParameter("item");
		// 	oList.insertItem(new ListItem({
		// 		title: "Upload completed: " + oItem.getFileName()
		// 	}));
		// },
		// onUploadAborted: function (oEvent) {
		// 	var oList = this.byId("progressList"),
		// 		oItem = oEvent.getParameter("item");
		// 	oList.insertItem(new ListItem({
		// 		title: "Upload aborted: " + oItem.getFileName()
		// 	}));
		// },
		onFileRenamed: function(oEvent) {
			MessageToast.show("FileRenamed event triggered.");
		}
	});
});
