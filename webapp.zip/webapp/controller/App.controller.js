sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("lmco.ces.preq.controller.App", {

		onInit : function () {
			var oViewModel,
				fnSetAppNotBusy,
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();


			// const hashChanger = sap.ui.core.routing.HashChanger.getInstance();

			// const oShell = sap.ushell.Container.getRenderer('fiori2').getShellConfig();
			// oShell.attachHomePress(function(oEvent){
			// 	sap.m.MessageToast.show('Home pressed');
			// })

			// hashChanger.attachEvent('hashChanged', function(oEvent){
			// 	const newHash = oEvent.getParameter('newHash');
			// })
				
			let _self = this,
				_sp = this.getOwnerComponent().getComponentData().startupParameters;
			let _amode = (!!_sp)?_sp.mode || []: [];
			let _mode = (_amode.length>0?_amode[0]:'');
			let _cMode = (_mode==='Approve'?'A':'');
			let _user = sap.ushell.Container.getService('UserInfo');
			let _usrId = _user.getId();

			// this._MessageManager = Core.getMessageManager();

			// let _key = this.getModel().createKey('/ContextSet',{'User':_user.getId()});
			let _key = "/ContextSet(User='"+_usrId+"',Mode='"+_cMode+"')";
			// this.getModel().createKey('/ContextSet',{'User':_usrId,'Mode':_mode})			

			oViewModel = new JSONModel({
				busy : true,
				delay : 0,
				approveMode : (_mode==='Approve'),
				opmode: '',
				editMode: false,
				reviewer: null,
				itemView: false,
				reqView: false,			
				layout : "OneColumn",
				itemLayout:"",
				bUserExist: true,
				bInputter: false,
				user: _user.getId(),
				fullName: _user.getFullName(),
				xcsrf: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token'],
				debugUser:'',
				useDebug:false,
				iApprCnt: '0',
				iHistCnt: '0',
				iCnt: '0',
				importSheet: 'UPLOAD',
				headerRow: 0,
				bConfHeader:false,
				bConfMap:false,
				bSelSheet:false,
				previousLayout : "",
				actionButtonsInfo : {
					midColumn : {
						fullScreen : false
					},
					endColumn : {
						fullScreen : false
					}
				}
			});

			this.getOwnerComponent().setModel(oViewModel, "appView");

			// OData.request({
			// 	requestUri: this['get']().sServiceUrl,
			// 	method: "GET",
			// 	async: false,
			// 	headers: {
			// 		"X-Requested-With": "XMLHttpRequest",
			// 		"Content-Type": "application/atom+xml",
			// 		"DataServiceVersion": "2.0",
			// 		"X-CSRF-Token": "Fetch"
			// 	}
			// 	}, function(data, response) {	
			// 		_self["x-csrf-token"] = response.headers['x-csrf-token'];
			// 		_promise.resolve(data,response);
			// 	});

			this.getModel().attachBatchRequestFailed(this._batchFailed,this);
			this.getModel().attachRequestFailed(this._batchFailed,this);
			// this.getModel().attachPropertyChange(function(oEvent){
			// 	sap.ushell.Container.setDirtyFlag(true);
			// }, this);


			this.getModel().read(_key, {
				// filters: [new sap.ui.model.Filter('Mode','EQ',_amode)],
				success: function(oData) {
					let _mdl = _self.getModel('appView');

					let SheetName = 'UPLOAD',
						HeaderRow = 0,
						bConfHeader = false,
						bConfMap = false,
						bSelSheet = false;


					_mdl.setProperty('/user',oData.User);
					_mdl.setProperty('/iApprCnt',oData.iApprCnt.toString());
					_mdl.setProperty('/iSubmitCnt',oData.iSubmitCnt.toString());
					_mdl.setProperty('/iHistCnt',oData.iHistCnt.toString());
					_mdl.setProperty('/iCnt',oData.iCnt.toString());
					_mdl.setProperty('/bUserExist',oData.bExist);
					_mdl.setProperty('/bInputter',oData.bInputter);
					_mdl.setProperty('/debugUser',oData.DebugUser);
					_mdl.setProperty('/useDebug',(!!oData.DebugUser)?true:false);	
					_mdl.setProperty('/bAdvanced',oData.bAdvanced);	
					// let _tabs = this.byId('masterTabBar');
					// if(oData.iApprCnt<=0 && oData.iSubmitCnt>0){
					// 	_tabs.setSelectedKey('submitted');
					// }


					if(oData.bAdvanced){
						_self._getPersonalization("lmco.ces").then(function (oContainer) {
							if (oContainer) {
			
								SheetName = oContainer.getItemValue('ImportSheet') || 'UPLOAD';
								HeaderRow = oContainer.getItemValue('HeaderRow') || 0;
								bConfHeader = oContainer.getItemValue('ConfirmHeaderRow') || false;
								bConfMap = oContainer.getItemValue('ConfirmMapping') || false;
								bSelSheet = oContainer.getItemValue('SelectSheet') || false;			
								if(bSelSheet) SheetName = '';				
							}
						});	
					}

					_mdl.setProperty('/importSheet',SheetName);
					_mdl.setProperty('/headerRow',HeaderRow);
					_mdl.setProperty('/bConfHeader',bConfHeader);
					_mdl.setProperty('/bConfMap',bConfMap);
					_mdl.setProperty('/bSelSheet',bSelSheet);
					_mdl.refresh(true);

				},
				fail: function(oError){
				}
			});

			


			fnSetAppNotBusy = function() {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			};

			// since then() has no "reject"-path attach to the MetadataFailed-Event to disable the busy indicator in case of an error
			this.getOwnerComponent().getModel().metadataLoaded().then(fnSetAppNotBusy);
			this.getOwnerComponent().getModel().attachMetadataFailed(fnSetAppNotBusy);

			// apply content density mode to root view
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		},

		_getPersonalization : function (appId, context) {
            if (this.__value(sap, "ushell.Container")) {
                this.PersonalizationService = sap.ushell.Container.getService("Personalization");

                return this.PersonalizationService.getContainer(appId, {
                    keyCategory         : this.PersonalizationService.constants.keyCategory.FIXED_KEY,
                    writeFrequency      : this.PersonalizationService.constants.writeFrequency.LOW,
                    clientStorageAllowed: true,
                    validity            : "infinity"
                }, context);
            } else {
                jQuery.sap.log.error("No sap.ushell.Container not found!  Cannot load personalization.");
                jQuery.sap.log.error("Loading Personalization container failed.");

                return Promise.resolve();
            }
        },

		__value: function(__object__, parts, defaultValue) {
			var __parts = parts.split('.');
			var temp = __object__;

			if (!parts || !__parts) {
				return __object__ ? __object__ : defaultValue;
			}

			for (var i = 0; i < __parts.length; i++) {
				var part = __parts[i];

				if (temp) {
					if ($.isFunction(temp[part])) {
						temp = temp[part]();
					} else {
						temp = temp[part];
					}
				} else {
					return defaultValue;
				}
			}

			return temp ? temp : defaultValue;
		},

		onExit: function(oEvent){

			// let _editMode = this.getModel("appView").getProperty("/editMode");

			// if(!!_editMode){
			// 	this._cancelEdit(oEvent);	
			// } 

			this.getModel().detachBatchRequestFailed(this._batchFailed,this);
			this.getModel().detachRequestFailed(this._batchFailed,this);
		
		},

		onAfterRendering: function() {
			// var homeBtn = sap.ui.getCore().byId("homeBtn").getDomRef();	
			// $($(homeBtn).find("a")).on("click", function(event) {
			// 	// do this if user do not want to navigate to launchpad
			// 	event.preventDefault();
			// });
		},
		
		_batchFailed: function(oEvent){

			try {
				let _msg = JSON.parse(oEvent.getParameter('response').responseText);
				sap.m.MessageBox.error(_msg.error.message.value);
			}
			catch(oError){
				// Do not display anyting
			}

		}

	});
});