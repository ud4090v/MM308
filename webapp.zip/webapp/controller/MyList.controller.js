sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter",
	"sap/ui/core/format/DateFormat"
], function (BaseController, JSONModel, Filter, FilterOperator, Sorter, GroupHeaderListItem, Device, Fragment, formatter, DateFormat) {
	"use strict";

	var controller;

	return BaseController.extend("lmco.ces.preq.controller.MyList", {

		formatter: formatter,
		
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit : function () {
			// Control state model
			
			var oList = this.byId("__preqList");

			this._oGroupFunctions = {
				CompanyName: function (oContext) {
					var sCompanyName = oContext.getProperty("Customer/CompanyName");
					return {
						key: sCompanyName,
						text: sCompanyName
					};
				},

				OrderDate: function (oContext) {
					var oDate = oContext.getProperty("OrderDate"),
						iYear = oDate.getFullYear(),
						iMonth = oDate.getMonth() + 1,
						sMonthName = this._oMonthNameFormat.format(oDate);

					return {
						key: iYear + "-" + iMonth,
						text: this.getResourceBundle().getText("masterGroupTitleOrderedInPeriod", [sMonthName, iYear])
					};
				}.bind(this),

				ShippedDate: function (oContext) {
					var oDate = oContext.getProperty("ShippedDate");
					// Special handling needed because shipping date may be empty (=> not yet shipped).
					if (oDate != null) {
						var iYear = oDate.getFullYear(),
							iMonth = oDate.getMonth() + 1,
							sMonthName = this._oMonthNameFormat.format(oDate);

						return {
							key: iYear + "-" + iMonth,
							text: this.getResourceBundle().getText("masterGroupTitleShippedInPeriod", [sMonthName, iYear])
						};
					} else {
						return {
							key: 0,
							text: this.getResourceBundle().getText("masterGroupTitleNotShippedYet")
						};
					}
				}.bind(this)
			};
			this._oMonthNameFormat = DateFormat.getInstance({ pattern: "MMMM"});

			this._oList = oList;

			// keeps the filter and search state
			this._oListFilterState = {
				aFilter : [],
				aSearch : []
			};

			// this.setModel(oViewModel, "masterView");
			oList.attachEventOnce("updateFinished", function(){
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			this.getRouter().getRoute("master").attachMatched(this._onMyListMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		onUpdateFinished : function (oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
		},

		onSearch : function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");

			if (sQuery) {
				this._oListFilterState.aSearch = [new Filter("PreqText", FilterOperator.Contains, sQuery)];
			} else {
				this._oListFilterState.aSearch = [];
			}
			this._applyFilterSearch();

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh : function () {
			var oList = this.byId("__preqList");
			oList.getBinding("items").refresh();
		},

		// /**
		//  * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
		//  * @param {sap.ui.base.Event} oEvent the button press event
		//  * @public
		//  */
		// onCreateNewRequest: function(oEvent) {
		// 	let _self = this;
		// 	controller = this;

		// 	this.getModel().read("/PlantSet", {
		// 		success: function(oData) {
		// 			let _mdl = new JSONModel(oData.results);

		// 			let	_oNew = new lmco.ces.core.newPRR({
		// 				allowServices: true,
		// 				sites: {
		// 					path: 'pl>/',
		// 					text: '{pl>Name}',
		// 					key:  '{pl>PlantID}',
		// 					dcma: '{pl>DCMA}'
		// 				},
		// 				completed: function(oEvent){
		// 					let _data = oEvent.getParameter('answers');
		
		// 					_self._onCreateNewReq(_data);

		// 					// if((_data.hwdeliverable && !_data.lmuse) || _data.Foreign){
		// 					// 	sap.m.MessageBox.error("DO NOT proceed with this form. COS/SAP must be used according to MM-2-001 MMAS.", {
		// 					// 		title: 'Caution!'
		// 					// 	});						
		// 					// } else {
		// 					// 	_self._onCreateNewReq(_data);
		// 					// }
		// 				}
		// 			});
		// 			_self.getView().addDependent(_oNew);
		// 			_oNew.setModel(_mdl,'pl');
		// 			_oNew.open();
		
		// 		},
		// 		// filters: [new Filter('DCMA','EQ',true)]
		// 	});

		// },

		// _onCreateNewReq: function(oData){
		// 	let _newData = this.getModel().createEntry('/HeaderSet').getObject();
		// 	let _user = this.getUser();


		// 	if(oData){
		// 		_newData.Plant = oData.Plant;
		// 		_newData.PlantName = oData.PlantName;
		// 		_newData.DCMA = !!oData.DCMA_Cert;
		// 		_newData.bMaterial = !!oData.bMaterial;
		// 		_newData.bOverLimit = !oData.under250;
		// 		_newData.bDeliverable = !!oData.hwdeliverable;
		// 		_newData.bLMuse = !!oData.lmuse;
		// 		_newData.PreqName = oData.cartNameSuffix;
		// 		_newData.City = oData.shipCity;
		// 		_newData.Pstlz = oData.shipPostalCode1;
		// 		_newData.POBox = oData.shipPOBox;
		// 		_newData.Street = oData.shipStreet;
		// 		_newData.HouseNo = oData.shipHouseNo;
		// 		_newData.Locat = oData.shipStreet2;
		// 		_newData.Building = oData.shipBuilding;
		// 		_newData.Floor = oData.shipFloor;
		// 		_newData.RoomNo = oData.shipRoomNo;
		// 		_newData.Country = oData.Country;
		// 		_newData.State = oData.shipRegion;
		// 		_newData.TelNumber = oData.TelNumbr;
		// 		_newData.bForeign = oData.Foreign;
		// 		_newData.Bukrs = oData.Bukrs;
		// 		_newData.Butxt = oData.Butxt;
		// 		_newData.CName = _user.getId();
		// 		_newData.CNameFull = _user.getFullName();
		// 		_newData.CNameEmail = _user.getEmail();
		// 	}

		// 	let _mdl = new JSONModel(_newData);

		// 	this._newDlg = sap.ui.xmlfragment("__newRequestDlg", "lmco.ces.preq.view.fragments.CreateNewRequest", this)

		// 	this.getView().addDependent(this._newDlg);
		// 	this._newDlg.setModel(_mdl,'mHdr');
		// 	this._newDlg.open();


		// },

		// getCompliance: function(oData){

		// },

		// onConfirmCreateNewRequest: function(oEvent){

		// 	let _data = oEvent.oSource.getModel('mHdr').oData;

		// 	let _pLoad = {};

		// 	Object.keys(_data).forEach((_k) => { 
		// 		_pLoad[_k] = (_data[_k] instanceof Date)? _data[_k].YYYYMMDD() :_data[_k];
		// 	})

		// 	controller.getOwnerComponent()._oErrorHandler._bMessageOpen = true;

        //     controller.getModel().create('/HeaderSet', _pLoad, {
		// 		success: function(oData){
		// 			if(controller._newDlg){
		// 				controller._newDlg.close();
		// 				controller._newDlg.destroy();				
		// 				controller._newDlg = null;
		// 			}
		
		// 			controller.getModel().refresh(true);
		// 		},
		// 		error: function(oError, oResponse){
		// 			let _msg = JSON.parse(oError.responseText);
		// 			sap.m.MessageBox.error(_msg.error.message.value);

		// 		}

		// 	})

		// },


		// onCreateOptionsChange: function(oEvent){
		// 	let _mdl = oEvent.oSource.getModel('mHdr'),
		// 		_data = _mdl.getProperty('/');

		// 	if(!_data.bMaterial) {
		// 		// _mdl.setProperty('/bOverLimit',false);
		// 		_mdl.setProperty('/bDeliverable',false);
		// 		_mdl.setProperty('/bLMuse',false);
		// 	}

		// 	// if(!_data.bOverLimit) {
		// 	// 	_mdl.setProperty('/bDeliverable',false);
		// 	// 	_mdl.setProperty('/bLMuse',false);
		// 	// }

		// 	if(!_data.bDeliverable) {
		// 		_mdl.setProperty('/bLMuse',false);
		// 	}


		// },

		// handleCancelNewRequest: function(oEvent){
		// 	if(controller._newDlg){
		// 		controller._newDlg.close();
		// 		controller._newDlg.destroy();				
		// 		controller._newDlg = null;
		// 	}
		// },

		// onOpenViewSettings : function (oEvent) {
		// 	var sDialogTab = "filter";
		// 	if (oEvent.getSource().isA("sap.m.Button")) {
		// 		var sButtonId = oEvent.getSource().getId();
		// 		if (sButtonId.match("sort")) {
		// 			sDialogTab = "sort";
		// 		} else if (sButtonId.match("group")) {
		// 			sDialogTab = "group";
		// 		}
		// 	}
		// 	// load asynchronous XML fragment
		// 	if (!this._pViewSettingsDialog) {
		// 		this._pViewSettingsDialog = Fragment.load({
		// 			id: this.getView().getId(),
		// 			name: "lmco.ces.preq.view.ViewSettingsDialog",
		// 			controller: this
		// 		}).then(function(oDialog){
		// 			// connect dialog to the root view of this component (models, lifecycle)
		// 			this.getView().addDependent(oDialog);
		// 			oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
		// 			return oDialog;
		// 		}.bind(this));
		// 	}
		// 	this._pViewSettingsDialog.then(function(oDialog) {
		// 		oDialog.open(sDialogTab);
		// 	});
		// },

		// onConfirmViewSettingsDialog : function (oEvent) {
		// 	var aFilterItems = oEvent.getParameter("filterItems"),
		// 		aFilters = [],
		// 		aCaptions = [];
		// 	aFilterItems.forEach(function (oItem) {
		// 		switch (oItem.getKey()) {
		// 			case "Shipped":
		// 				aFilters.push(new Filter("ShippedDate", FilterOperator.NE, null));
		// 				break;
		// 			case "NotShipped":
		// 				aFilters.push(new Filter("ShippedDate", FilterOperator.EQ, null));
		// 				break;
		// 			default:
		// 			break;
		// 		}
		// 		aCaptions.push(oItem.getText());
		// 	});
		// 	this._oListFilterState.aFilter = aFilters;
		// 	this._updateFilterBar(aCaptions.join(", "));
		// 	this._applyFilterSearch();
		// 	this._applyGrouper(oEvent);
		// },

		_applyGrouper: function (oEvent) {
			var oList = this.byId("__preqList");
			var mParams = oEvent.getParameters(),
				sPath,
				bDescending,
				aSorters = [];
			// apply sorter to binding
			if (mParams.groupItem) {
				mParams.groupItem.getKey() === "CompanyName" ?
					sPath = "Customer/" + mParams.groupItem.getKey() : sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				var vGroup = this._oGroupFunctions[mParams.groupItem.getKey()];
				aSorters.push(new Sorter(sPath, bDescending, vGroup));
			}
			oList.getBinding("items").sort(aSorters);
		},

		onSelectionChange : function (oEvent) {
			var oList = oEvent.getSource(),
				bSelected = oEvent.getParameter("selected");

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			}
		},

		onBypassed : function () {
			var oList = this.byId("__preqList");
			oList.removeSelections(true);
		},

		createGroupHeader : function (oGroup) {
			return new GroupHeaderListItem({
				title : oGroup.text,
				upperCase : false
			});
		},

		_onMyListMatched :  function(oEvent) {
			//Set the layout property of the FCL control to 'OneColumn'
			let _lst = this.byId('__preqList');

			if(_lst){
				let  _bi = _lst.getBindingInfo('items'),
					_tpl = _bi.template,
					_path = (_bi)?_bi.path:'',
					_bnd = (_bi)?_bi.binding:null,
					aSorters = (_bnd)?_bnd.aSorters:[new sap.ui.model.Sorter(_path)];


				let aFilters = [
					new Filter('CName', 'EQ', this.getUser().getId())
				]

				this.byId('__preqList').bindAggregation("items", {
					path: "/HeaderSet",
					template: _tpl,
					filters: aFilters,
					sorters: aSorters
				});

			}

		},

		_showDetail : function (oItem) {
			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getModel("appView").setProperty("/reqView", true);

			this.getRouter().navTo("object", {
				objectId : oItem.getBindingContext().getProperty("PrqNo")
			}, bReplace);
		},

		_updateListItemCount : function (iTotalItems) {
			var oList = this.byId("__preqList")
			// only update the counter if the length is final
			if (oList.getBinding("items").isLengthFinal()) {
				this.getModel("masterView").setProperty("/titleCount", iTotalItems);
			}
		},

		_applyFilterSearch : function () {
			var oList = this.byId("__preqList");
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		_updateFilterBar : function (sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		}

	});
});