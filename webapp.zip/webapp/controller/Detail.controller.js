sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	'sap/ui/core/Core',
	"sap/ui/core/message/Message",
	"sap/m/library",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",	
	"sap/base/util/deepExtend",
	'sap/ui/core/Element'
], function(BaseController, JSONModel, formatter, MessagePopover, MessageItem, Core,  Message, mobileLibrary, Filter, FilterOperator, deepExtend, Element) {
	"use strict";

	var controller, component;
	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;

	function _calculateOrderTotal (fPreviousTotal, oCurrentContext) {
		var fItemTotal = oCurrentContext.getObject().Quantity * oCurrentContext.getObject().UnitPrice;
		return fPreviousTotal + fItemTotal;
	}
	return BaseController.extend("lmco.ces.preq.controller.Detail", {

		formatter: formatter,
		oDataInitial: {
			// Static data
			Items: [],
			// Runtime data
			ColumnsItems: [],
			ShowResetEnabled: false
		},

		onInit : function () {

			// if(!controller) 
			controller = this;

			// if(!component) 
			component = this.getOwnerComponent();

			this.oView = this.getView();

			// var oVariantMgmtControl = this.getView().byId("variantManagement"),
            // oVariantModel = new sap.ui.model.json.JSONModel();

			// if(!!this.byId("lineItemsList")) {
			// 	let oPersModel = new JSONModel(deepExtend({}, this.fillPersData()));
			// 	this.getView().setModel(oPersModel, "pers");

			// 	this.getAllVariants(function(aVariants){
			// 		oVariantModel.oData.Variants = aVariants;
			// 		oVariantMgmtControl.setModel(oVariantModel);           
			// 		// oVariantMgmtControl.oVariantSave.onAfterRendering = function(){this.setEnabled(true);};
			// 	}.bind(this));
	
			// }


			// this._MessageManager = Messaging;
			// Clear the old messages
			this._MessageManager.removeAllMessages();		
			this._MessageManager.getMessageModel().attachMessageChange(this._onMessageUpdated, this);

			let _cc = this.oView.byId("iconTabBar");

			if(!!_cc) {
				this._MessageManager.registerObject(_cc, true);				
			}
			
			this.oView.setModel(this._MessageManager.getMessageModel(),"message");			

			this.createMessagePopover();

			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			this._aValidKeys = ["general","shipping", "attachments","itemList"];
			var oViewModel = new JSONModel({
				busy : false,
				delay : 0,
				selMode: 'None',
				itemDelMode: false,
				lineItemListTitle : this.getResourceBundle().getText("detailLineItemTableHeading"),
				// Set fixed currency on view model (as the OData service does not provide a currency).
				currency : "USD",
				// the sum of all items of this order
				totalOrderAmount: 0,
				selectedTab: ""
			});

			this.oRouter = this.getOwnerComponent().getRouter();

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		_onMessageUpdated: function(oEvent){
			let _self = this;
		},

		onExit: function(oEvent){
			this._MessageManager.getMessageModel().detachMessageChange(this._onMessageUpdated, this);
		},

		createMessagePopover: function () {
			var that = this;
			controller._btn = this.getView().byId("__validateMsg");

			this.oMP = new MessagePopover({
				activeTitlePress: function (oEvent) {
					var oItem = oEvent.getParameter("item"),
						oPage = that.getView().byId("page"),
						oMessage = oItem.getBindingContext("message").getObject(),
						oControl = Element.registry.get(oMessage.getControlId());

					if (oControl) {

						if (oControl) {
							// oPage.scrollToElement(oControl.getDomRef(), 200, [0, -100]);
							setTimeout(function(){
								oControl.focus();
								let _info = new sap.m.Popover({'title':oMessage.additionalText, 'placement':'Left','content':[new sap.m.TextArea({'value':oMessage.technicalDetails,'editable':false})]})
								_info.openBy(oControl);
							}, 300);
						}
	
						// oControl.focus();
						// let _info = new sap.m.Popover({'title':oMessage.additionalText, 'placement':'Left','content':[new sap.m.TextArea({'value':oMessage.technicalDetails,'editable':false})]})
						// _info.openBy(oControl);

						// oPage.scrollToElement(oControl.getDomRef(), 200, [0, -100]);
						// setTimeout(function(){
						// 	var bIsBehindOtherElement = isBehindOtherElement(oControl.getDomRef());
						// 	if (bIsBehindOtherElement) {
						// 		this.close();
						// 	}
						// 	if (oControl.isFocusable()) {
						// 		oControl.focus();
						// 	}
						// }.bind(this), 300);
					}
				},
				items: {
					path:"message>/",
					template: new MessageItem(
						{
							title: "{message>message}",
							groupName: "{message>code}",
							activeTitle: true,
							type: "{message>type}",
							subtitle: "{message>additionalText}",
							link: 
							// {
							// 	path: 'message>descriptionUrl',
							// 	formatter: function(sUrl){
							// 		if(!sUrl){
							// 			return null;
							// 		}
							// 		else {
							// 			return new sap.m.Link({
							// 				text: "Show more information",
							// 				href:  sUrl,
							// 				target: "_blank"
							// 			})
						
							// 		}						
							// 	}
							// },
							new sap.m.Link({
								text: "Show more information",
								href:  "{message>descriptionUrl}",
								target: "_blank",
								visible: {
									path: 'message>descriptionUrl',
									formatter: function(s){
										return (!!s)?true:false;
									}
								}
							}),
							description: "{message>description}"
						})
				},
				groupItems: true
			});

			if(controller._btn){
				controller._btn.addDependent(this.oMP);
			}

			// this.getView().byId("__validateMsg").addDependent(this.oMP);
		},

		createNotesPopover: function (oEvent) {
			var that = this,
				_sp = oEvent.oSource.getBindingContext().sPath;

			controller._btn = this.getView().byId("__notesList");

			this.oNotesDisp = new sap.m.Dialog({
				title: "Notes",
				contentWidth: "550px",
				contentHeight: "300px",
				content: new sap.m.NotificationList({
					items: {
						path: _sp+"/Notes",
						template: new sap.m.NotificationListItem({
							title: "{Fullname} on {Crtdat},{Crtime}",
							description: "{Note}",
							showCloseButton: false,
							datetime: {
								parts: [
									'Crtdat',
									'Crtime'
								],
								formatter: function(sDat, sTime) {
									let _d1 = new Date(sDat);
									let _ds = new Date(_d1.getFullYear()+'-'+String(_d1.getMonth()+1).padStart(2,'0')+'-'+String(_d1.getDate()).padStart(2,'0')+'T'+sTime);
									let _today = new Date();
									let _diff = _today - _ds,
										_days = Math.floor(_diff/(3600*24*1000)),
										_diff2 = _diff - (_days*3600*24*1000),
										_hrs = Math.floor(_diff2/(3600*1000)),
										_diff3 = _diff2 - (_hrs*3600*1000),
										_min = Math.floor(_diff3/(60*1000));

									let _sd = (_days>0)?_days.toString()+' days':'',
										_sh = (_hrs>0)?_hrs.toString()+' hrs':'',
										_sm = (_min>0)?_min.toString()+' min':'';
										
									return _sd+' '+_sh+' '+_sm;
								}
							},
							unread: true,
							authorName: "{Fullname}"
						})
					}
				}).addStyleClass('CESpreserveWhiteSpaces'),
				endButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "Close",
					press: function () {
						this.oNotesDisp.close();
					}.bind(this)
				})
			});



			if(controller._btn){
				controller._btn.addDependent(this.oNotesDisp);
			}

			// this.getView().byId("__validateMsg").addDependent(this.oMP);
		},

		getGroupName : function (sControlId) {
			// the group name is generated based on the current layout
			// and is specific for each use case
			var oControl = Element.registry.get(sControlId);

			if (oControl) {
				var sFormSubtitle = oControl.getParent().getParent().getTitle().getText(),
					sFormTitle = oControl.getParent().getParent().getParent().getTitle();

				return sFormTitle + ", " + sFormSubtitle;
			}
		},

		isPositionable : function (sControlId) {
			// Such a hook can be used by the application to determine if a control can be found/reached on the page and navigated to.
			return sControlId ? true : true;
		},


		buttonIconFormatter: function () {
			var sIcon;
			var aMessages = this._MessageManager.getMessageModel().oData;

			aMessages.forEach(function (sMessage) {
				switch (sMessage.type) {
					case "Error":
						sIcon = "sap-icon://error";
						break;
					case "Warning":
						sIcon = sIcon !== "sap-icon://error" ? "sap-icon://alert" : sIcon;
						break;
					case "Success":
						sIcon = "sap-icon://error" && sIcon !== "sap-icon://alert" ? "sap-icon://sys-enter-2" : sIcon;
						break;
					default:
						sIcon = !sIcon ? "sap-icon://information" : sIcon;
						break;
				}
			});

			sIcon = !sIcon ? "sap-icon://information" : sIcon;

			return sIcon;
		},

		buttonTypeFormatter: function () {
			var sHighestSeverity;
			var aMessages = this._MessageManager.getMessageModel().oData;
			aMessages.forEach(function (sMessage) {
				switch (sMessage.type) {
					case "Error":
						sHighestSeverity = "Negative";
						break;
					case "Warning":
						sHighestSeverity = sHighestSeverity !== "Negative" ? "Critical" : sHighestSeverity;
						break;
					case "Success":
						sHighestSeverity = sHighestSeverity !== "Negative" && sHighestSeverity !== "Critical" ?  "Success" : sHighestSeverity;
						break;
					default:
						sHighestSeverity = !sHighestSeverity ? "Neutral" : sHighestSeverity;
						break;
				}
			});

			sHighestSeverity = !sHighestSeverity ? "Neutral" : sHighestSeverity;

			return sHighestSeverity;
		},

		// Display the number of messages with the highest severity
		highestSeverityMessages: function () {
			var sHighestSeverityIconType = this.buttonTypeFormatter();
			var sHighestSeverityMessageType;

			switch (sHighestSeverityIconType) {
				case "Negative":
					sHighestSeverityMessageType = "Error";
					break;
				case "Critical":
					sHighestSeverityMessageType = "Warning";
					break;
				case "Success":
					sHighestSeverityMessageType = "Success";
					break;
				default:
					sHighestSeverityMessageType = !sHighestSeverityMessageType ? "Information" : sHighestSeverityMessageType;
					break;
			}

			sHighestSeverityMessageType = !sHighestSeverityMessageType ? "Information" : sHighestSeverityMessageType;
			
			return this._MessageManager.getMessageModel().oData.reduce(function(iNumberOfMessages, oMessageItem) {
				return oMessageItem.type === sHighestSeverityMessageType ? ++iNumberOfMessages : iNumberOfMessages;
			}, 0) || "";
		},


		handleMessagePopoverPress: function (oEvent) {
			if (!this.oMP) {
				this.createMessagePopover();
			}
			this.oMP.toggle(oEvent.getSource());
		},

		validateHeader: function (oContext) {
			var 
				_ctx = oContext.getObject(),
				self = this,
				_mdl = oContext.oModel,
				_promise = $.Deferred();
				// _fld = controller.byId('_chargeCode'),
				// oBinding = oInput.getBinding("value"),
				// oBinding = _fld.getBinding("value"),
				// sTarget = _fld.getBindingContext().getPath() + "/" + _fld.getBindingPath("value");

			let _vData = {
				PrqNr: _ctx.PrqNo
			};

			_mdl.callFunction("/validateRequest", {
				urlParameters : _vData,
				success : function(oData, response) {
					_promise.resolve(oData, response);

				},
				error : function(oError) {
					_promise.reject(oError);
				},
			});

			return _promise;

			// this.removeMessageFromTarget(sTarget);

			// try {
			// 	oBinding.getType().validateValue(oInput.getValue());
			// } catch (oException) {
			// 	sValueState = "Warning";
			// 	this._MessageManager.addMessages(
			// 		new Message({
			// 			message: "The value should not exceed 40",
			// 			type: MessageType.Warning,
			// 			additionalText: oInput.getLabels()[0].getText(),
			// 			description: "The value of the working hours field should not exceed 40 hours.",
			// 			target: sTarget,
			// 			processor: this.getView().getModel()
			// 		})
			// 	);
			// }
			// _fld.setValueState("Error");

			// oInput.setValueState(sValueState);
		},

		synchronizeHeader: function (oContext) {
			var 
				_ctx = oContext.getObject(),
				self = this,
				_mdl = oContext.oModel,
				_promise = $.Deferred();

			let _vData = {
				prrnr: _ctx.PrqNo
			};

			_mdl.callFunction("/refreshHeader", {
				urlParameters : _vData,
				success : function(oData, response) {
					_promise.resolve(oData, response);

				},
				error : function(oError) {
					_promise.reject(oError);
				},
			});

			return _promise;

		},


		onReqValidate: function (oEvent) {
			var oButton = this.getView().byId('__validateMsg'),
				_ctx = oEvent.oSource.getBindingContext(),
				_self = this,
				_mdl = _ctx.oModel;
			let _user = this.getUser();

			var _key = _mdl.createKey("/HeaderSet", {
					"PrqNo": _ctx.getObject().PrqNo,
					"Userid": _user.getId()
				});
	
			// oButton.setVisible(true);
			this._MessageManager.removeAllMessages();

			this.validateHeader(_ctx)
			.done(function(oMsg){
				_self.displayMessages(oMsg.results);

			})
			.fail(function(oError){

			})
			// // this.handleRequiredField(oRequiredNameInput);
			// // this.checkInputConstraints(iWeeklyHours);

			// this.oMP.getBinding("items").attachChange(function(oEvent){
			// 	this.oMP.navigateBack();
			// 	oButton.setType(this.buttonTypeFormatter());
			// 	oButton.setIcon(this.buttonIconFormatter());
			// 	oButton.setText(this.highestSeverityMessages());
			// }.bind(this));

			// setTimeout(function(){
			// 	this.oMP.openBy(oButton);
			// }.bind(this), 100);
		},

		onReqSynch: function (oEvent) {
			var _ctx = oEvent.oSource.getBindingContext(),
				_self = this,
				_mdl = _ctx.oModel;
			let _user = this.getUser();

			var _key = _mdl.createKey("/HeaderSet", {
					"PrqNo": _ctx.getObject().PrqNo,
					"Userid": _user.getId()
				});
	
			// oButton.setVisible(true);
			this._MessageManager.removeAllMessages();

			this.synchronizeHeader(_ctx)
			.done(function(oMsg){
				sap.m.MessageToast.show('Data synchrozined')
				_mdl.refresh(true);
				// _self.displayMessages(oMsg.results);

			})
			.fail(function(oError){

			})
			// // this.handleRequiredField(oRequiredNameInput);
			// // this.checkInputConstraints(iWeeklyHours);

			// this.oMP.getBinding("items").attachChange(function(oEvent){
			// 	this.oMP.navigateBack();
			// 	oButton.setType(this.buttonTypeFormatter());
			// 	oButton.setIcon(this.buttonIconFormatter());
			// 	oButton.setText(this.highestSeverityMessages());
			// }.bind(this));

			// setTimeout(function(){
			// 	this.oMP.openBy(oButton);
			// }.bind(this), 100);
		},


		onChangePostItem: function(oEvent){
			_stream.update(param.Data.sPath, _data, {
				async : false,
				success : function(oData, response) {
					_promise.resolve(oData,response);
				},
				error : function(oError, response) {
					_promise.reject(oError, response);
				},
			});

		},

		onSubmitRequest: function (oEvent) {
	
			// oButton.setVisible(true);
			var _self = this,
				_ctx = oEvent.oSource.getBindingContext(),
				_item = _ctx.getObject();
			
			if(_item.bReview){
				this.onReviewRequest(oEvent);
			} else if(_item.bCCApprove) {
				this.sendCCApprEmail(oEvent);
			} else {
				this.validateHeader(_ctx)
				.done(function(oMsg){
					if(oMsg.results.length>0){
						let _eCnt = oMsg.results.filter((mm) => { return mm.Type==='Error' }).length,
							_wCnt = oMsg.results.filter((mm) => { return mm.Type==='Warning' }).length;
	
						if(_eCnt>0){
							sap.m.MessageBox.error("Request contains error. Please review and fix before Submitting");
							_self.displayMessages(oMsg.results);
							return false;
						} else if(_wCnt>0) {
							sap.m.MessageBox.warning("There are some warnings in your request. You can still submit it, or cancel to review the warnings", {
								actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
								emphasizedAction: sap.m.MessageBox.Action.OK,
								onClose: function (sAction) {
									if(sAction===sap.m.MessageBox.Action.OK) {
										_self._submitRequest(_ctx);
										//  submit form for review
									} else {
										_self.displayMessages(oMsg.results);
										return false;
									}
								},
								dependentOn: _self.getView()
							});						
						}
	
					} else {
						_self._submitRequest(_ctx);
						//  update status to 008
					}
	
	
				})
				.fail(function(oError){
	
				})	
			}

		},

		sendCCApprEmail: function(oEvent){
			let _user = this.getUser();
			let _obj = oEvent.oSource.getBindingContext().getObject();
			let cNav = sap.ushell.Container.getService("CrossApplicationNavigation"),
				aPath = cNav.hrefForExternal({
					target : { semanticObject : "CESPREQ", action : "CCApprove" }
				  });

			let _pLoad = {};
	
				controller.getModel().create('/EmailSet', {
					UserId: _user.getId(),
					Prrnr: _obj.PrqNo,
					Url: window.location.origin + window.location.pathname + aPath
				}, {
					success: function(oData){
						sap.m.MessageToast.show('Approval Request(s) were sent to Cost Center Managers')
					},
					error: function(oError, oResponse){
						let _msg = JSON.parse(oError.responseText);
						sap.m.MessageBox.error(_msg.error.message.value);
	
					}
	
				})
	

		},

		onReviewRequest: function (oEvent) {

			var _self = this,
				oContext = oEvent.oSource.getBindingContext();

			let _user = this.getUser();						
			let _ctx = oContext.getObject(),
				self = this,
				_app = this.getOwnerComponent().getModel('appView'),
				_mdl = oContext.oModel;

			var _mkey = _mdl.createKey("/HeaderSet", {
				PrqNo :  _ctx.PrqNo,
				Userid :  _user.getId()
			});

			_mdl.setProperty(_mkey+'/Status', '016');
			_mdl.setProperty(_mkey+'/Inputter', _user.getId());

			_mdl.submitChanges({
				success: function(oData){
					let _key = "/ContextSet(User='"+_user.getId()+"',Mode='A')";
		
					_mdl.read(_key, {
						success: function(oData) {
							_app.setProperty("/layout", "OneColumn");
							_app.setProperty('/iApprCnt',oData.iApprCnt.toString());
							_app.setProperty('/iSubmitCnt',oData.iSubmitCnt.toString());
							_app.setProperty('/iHistCnt',oData.iHistCnt.toString());
							_app.setProperty('/iCnt',oData.iCnt.toString());
							_app.refresh(true);
		
						},
						fail: function(oError){
						}
					});
					_mdl.refresh(true);
				},
				error: function(oError){
					let _msg = JSON.parse(oError.responseText);
					sap.m.MessageBox.error(_msg.error.message.value);	
				}
			})

		},

		onReturnRequest: function (oEvent) {

			var _self = this,
				oContext = oEvent.oSource.getBindingContext();

			let _user = this.getUser();						
			let _ctx = oContext.getObject(),
				self = this,
				_app = this.getOwnerComponent().getModel('appView'),
				_mdl = oContext.oModel;

			var _mkey = _mdl.createKey("/HeaderSet", {
				PrqNo :  _ctx.PrqNo,
				Userid :  _user.getId()
			});

			_mdl.setProperty(_mkey+'/Status', '008');
			// _mdl.setProperty(_mkey+'/Inputter', '');

			_mdl.submitChanges({
				success: function(oData){
					let _key = "/ContextSet(User='"+_user.getId()+"',Mode='A')";
		
					_mdl.read(_key, {
						success: function(oData) {
							_app.setProperty("/layout", "OneColumn");
							_app.setProperty('/iApprCnt',oData.iApprCnt.toString());
							_app.setProperty('/iSubmitCnt',oData.iSubmitCnt.toString());
							_app.setProperty('/iHistCnt',oData.iHistCnt.toString());
							_app.setProperty('/iCnt',oData.iCnt.toString());
							_app.refresh(true);
		
						},
						fail: function(oError){
						}
					});
					_mdl.refresh(true);
				},
				error: function(oError){
					let _msg = JSON.parse(oError.responseText);
					sap.m.MessageBox.error(_msg.error.message.value);	
				}
			})

		},

		onRejectRequest: function(oEvent) {
			var _self = this,
				oContext = oEvent.oSource.getBindingContext();

			let _user = this.getUser();						
			let _ctx = oContext.getObject(),
				self = this,
				_mdl = oContext.oModel,
				_app = this.getOwnerComponent().getModel('appView');


			var _sNote = new sap.m.TextArea({
				width: "100%",
				placeholder: "Add note"
			});

			let _newData = this.getModel().createEntry('/NotesSet').getObject();

			if (!this.oRejectDialog) {
				this.oRejectDialog = new sap.m.Dialog({
					title: "Reject",
					type: sap.m.DialogType.Message,
					content: [
						new sap.m.Label({
							text: "Do you want to reject this request?",
							labelFor: _sNote.getId()
						}),
						_sNote
					],
					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "Reject",
						press: function () {
							var sText = _sNote.getValue();
							let _user = _self.getUser();
							var _mkey = _mdl.createKey("/HeaderSet", {
								PrqNo :  _ctx.PrqNo,
								Userid :  _user.getId()
							});
							let _now = new Date();

							// var sText = Element.getElementById("rejectionNote").getValue();
							if(sText.length<1) {
								sText = 'Rejected by ' + _user.getFullName() + ' on ' + _now.YYYYMMDD();
								// sap.m.MessageToast.show('Please add a note explaining why you are rejecting it and what needs to be fixed.')
							} 
							// else {
								_mdl.setProperty(_mkey+'/Status', '004');
								_mdl.setProperty(_mkey+'/Inputter', '');

								_mdl.createEntry('/NotesSet',{
									properties:{
										'Prrnr':_ctx.PrqNo,
										'Crtdat':_now.YYYYMMDD(),
										'Crtime':_now.toLocaleTimeString('en-US', { hourCycle: 'h24' }),
										'Crtnam':_user.getId(),
										'Note': sText
									}
								})				
									
								_mdl.submitChanges({
									success: function(oData){
										let _key = "/ContextSet(User='"+_user.getId()+"',Mode='')"

		
										_mdl.read(_key, {
											success: function(oData) {
												_app.setProperty("/layout", "OneColumn");
												_app.setProperty('/iApprCnt',oData.iApprCnt.toString());
												_app.setProperty('/iSubmitCnt',oData.iSubmitCnt.toString());
												_app.setProperty('/iHistCnt',oData.iHistCnt.toString());
												_app.setProperty('/iCnt',oData.iCnt.toString());
												_mdl.setProperty('/debugUser',oData.DebugUser);
												_mdl.setProperty('/useDebug',(!!oData.DebugUser)?true:false);											
												_app.refresh(true);
							
											},
											fail: function(oError){
											}
										});
					
										_mdl.refresh(true);
									},
									error: function(oError){
										let _msg = JSON.parse(oError.responseText);
										_self._MessageManager.removeAllMessages();
										sap.m.MessageBox.error(_msg.error.message.value);	
									}
								})
					
					
							// }
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;

						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();


		},

		onCompleteRequest: function(oEvent) {
			var _self = this,
				oContext = oEvent.oSource.getBindingContext();

			let _user = this.getUser();						
			let _ctx = oContext.getObject(),
				self = this,
				_mdl = oContext.oModel,
				_app = this.getOwnerComponent().getModel('appView');


			var _sNote = new sap.m.TextArea({
				width: "100%",
				placeholder: "Add note"
			});

			// var _sPR = new sap.m.Input({
			// 	width: "100%",
			// 	placeholder: "Enter P2P PR Number",
			// 	visible: _ctx.bHasServices
			// });

			// var _sPRLabel = new sap.m.Label({text: 'P2P PR Number:', visible: _ctx.bHasServices});

	//		let _newData = this.getModel().createEntry('/NotesSet').getObject();

			if (!this.oRejectDialog) {
				this.oRejectDialog = new sap.m.Dialog({
					title: "Complete",
					type: sap.m.DialogType.Message,
					content: [
						new sap.m.Label({
							text: "Do you want to complete this request?",
							labelFor: _sNote.getId()
						}),
						_sNote
						// _sPRLabel,
						// _sPR
					],
					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "Complete",
						press: function () {
							var sText = _sNote.getValue();
							// let _pr = _sPR.getValue() || '';
							let _user = _self.getUser();
							var _mkey = _mdl.createKey("/HeaderSet", {
								PrqNo :  _ctx.PrqNo,
								Userid :  _user.getId()
							});


							// var sText = Element.getElementById("rejectionNote").getValue();
							// if(_ctx.bHasServices){
							// 	_mdl.setProperty(_mkey+'/P2PBanfn', _pr);
							// }

							_mdl.setProperty(_mkey+'/Status', '064');

							if(sText.length>1) {
								let _now = new Date();
								// _mdl.createEntry('/NotesSet',{
								// 	properties:{
								// 		'Prrnr':_ctx.PrqNo,
								// 		'Crtdat':_now.YYYYMMDD(),
								// 		'Crtime':_now.toLocaleTimeString('en-US', { hourCycle: 'h24' }),
								// 		'Crtnam':_user.getId(),
								// 		'Note': sText
								// 	}
								// })					
							}

							controller.getOwnerComponent()._oErrorHandler._bMessageOpen = true;
								
							_mdl.submitChanges({
								success: function(oData){

									if(oData.__batchResponses[0].response.statusCode === '200') {
										let _key = "/ContextSet(User='"+_user.getId()+"',Mode='A')"

										_mdl.resetChanges();
										_mdl.read(_key, {
											success: function(oData) {
												_app.setProperty("/layout", "OneColumn");
												_app.setProperty('/iApprCnt',oData.iApprCnt.toString());
												_app.setProperty('/iSubmitCnt',oData.iSubmitCnt.toString());
												_app.setProperty('/iHistCnt',oData.iHistCnt.toString());
												_app.setProperty('/iCnt',oData.iCnt.toString());
												_app.refresh(true);
							
											},
											fail: function(oError){
											}
										});
										_mdl.refresh(true);
									} else {
										_mdl.resetChanges();
									}
				
								},
								error: function(oError){
									let _msg = JSON.parse(oError.responseText);
									_self._MessageManager.removeAllMessages();
									sap.m.MessageBox.error(_msg.error.message.value);	
									oMdl.hasPendingChanges();
								}
							})
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;

						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();


		},

		onAddNote: function(oEvent) {
			var _self = this,
				oContext = oEvent.oSource.getBindingContext();

			let _user = this.getUser();						
			let _ctx = oContext.getObject(),
				self = this,
				_mdl = oContext.oModel,
				_app = this.getOwnerComponent().getModel('appView');


			var _sNote = new sap.m.TextArea({
				width: "100%",
				placeholder: "Add note"
			});

			// var _sPR = new sap.m.Input({
			// 	width: "100%",
			// 	placeholder: "Enter P2P PR Number",
			// 	visible: _ctx.bHasServices
			// });

			// var _sPRLabel = new sap.m.Label({text: 'P2P PR Number:', visible: _ctx.bHasServices});

	//		let _newData = this.getModel().createEntry('/NotesSet').getObject();

			if (!this.oRejectDialog) {
				this.oRejectDialog = new sap.m.Dialog({
					title: "Complete",
					type: sap.m.DialogType.Message,
					content: [
						new sap.m.Label({
							text: "Add comments below",
							labelFor: _sNote.getId()
						}),
						_sNote
						// _sPRLabel,
						// _sPR
					],
					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "Add Note",
						press: function () {
							var sText = _sNote.getValue();
							// let _pr = _sPR.getValue() || '';
							let _user = _self.getUser();

							if(sText.length>1) {
								let _now = new Date();
								_mdl.createEntry('/NotesSet',{
									properties:{
										'Prrnr':_ctx.PrqNo,
										'Crtdat':_now.YYYYMMDD(),
										'Crtime':_now.toLocaleTimeString('en-US', { hourCycle: 'h24' }),
										'Crtnam':_user.getId(),
										'Note': sText
									}
								})					
							}
								
							_mdl.submitChanges({
								success: function(oData){

									if(oData.__batchResponses[0].response.statusCode === '200') {
										_mdl.refresh(true);
									} else {
										_mdl.resetChanges();
									}
				
								},
								error: function(oError){
									let _msg = JSON.parse(oError.responseText);
									_self._MessageManager.removeAllMessages();
									sap.m.MessageBox.error(_msg.error.message.value);	
									_mdl.resetChanges();
									// oMdl.hasPendingChanges();
								}
							})
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;

						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();


		},


		onCancelRequest: function(oEvent) {
			var _self = this,
				oContext = oEvent.oSource.getBindingContext();

			let _user = this.getUser();						
			let _ctx = oContext.getObject(),
				self = this,
				_mdl = oContext.oModel,
				_app = this.getOwnerComponent().getModel('appView');


			var _sNote = new sap.m.TextArea({
				width: "100%",
				placeholder: "Add note"
			});

			let _newData = this.getModel().createEntry('/NotesSet').getObject();

			if (!this.oRejectDialog) {
				this.oRejectDialog = new sap.m.Dialog({
					title: "Withdraw",
					type: sap.m.DialogType.Message,
					content: [
						new sap.m.Label({
							text: "Do you want to withdraw this request?",
							labelFor: _sNote.getId()
						}),
						_sNote
					],
					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "Withdraw",
						press: function () {
							var sText = _sNote.getValue();
							let _user = _self.getUser();
							var _mkey = _mdl.createKey("/HeaderSet", {
								PrqNo :  _ctx.PrqNo,
								Userid :  _user.getId()
							});
							let _now = new Date();

							// var sText = Element.getElementById("rejectionNote").getValue();
							if(sText.length<1) {
								sText = 'Withdrawn by ' + _user.getFullName() + ' on ' + _now.YYYYMMDD();
								// sap.m.MessageToast.show('Please add a note explaining why you are withdrawing this request.')
							} 
							// else {
								_mdl.setProperty(_mkey+'/Status', '999');

								_mdl.createEntry('/NotesSet',{
									properties:{
										'Prrnr':_ctx.PrqNo,
										'Crtdat':_now.YYYYMMDD(),
										'Crtime':_now.toLocaleTimeString('en-US', { hourCycle: 'h24' }),
										'Crtnam':_user.getId(),
										'Note': sText
									}
								})				
									
								_mdl.submitChanges({
									success: function(oData){
										let _key = "/ContextSet(User='"+_user.getId()+"',Mode='')"

		
										_mdl.read(_key, {
											success: function(oData) {
												_app.setProperty("/layout", "OneColumn");
												_app.setProperty('/iApprCnt',oData.iApprCnt.toString());
												_app.setProperty('/iSubmitCnt',oData.iSubmitCnt.toString());
												_app.setProperty('/iHistCnt',oData.iHistCnt.toString());
												_app.setProperty('/iCnt',oData.iCnt.toString());
												_app.refresh(true);
							
											},
											fail: function(oError){
											}
										});
					
										_mdl.refresh(true);
									},
									error: function(oError){
										let _msg = JSON.parse(oError.responseText);
										_self._MessageManager.removeAllMessages();
										sap.m.MessageBox.error(_msg.error.message.value);	
									}
								})
					
					
							// }
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							this.oRejectDialog.close();
							this.oRejectDialog.destroy();
							this.oRejectDialog = null;

						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();


		},


		onDisplayNotes: function(oEvent){
			if (!this.oNotesDisp) {
				this.createNotesPopover(oEvent);
			}
			this.oNotesDisp.open();

		},

		onPostRequest: function(oEvent) {
			var _self = this,
				oContext = oEvent.oSource.getBindingContext();

			let _user = this.getUser();						
			let _ctx = oContext.getObject(),
				self = this,
				_app = this.getOwnerComponent().getModel('appView'),
				_mdl = oContext.oModel;

			// let _newData = this.getModel().createEntry('/NotesSet').getObject();
			this.validateHeader(oContext)
			.done(function(oMsg){
				let _eCnt = 0,
					_wCnt = 0;

				if(oMsg.results.length>0){
					_eCnt = oMsg.results.filter((mm) => { return mm.Type==='Error' }).length,
					_wCnt = oMsg.results.filter((mm) => { return mm.Type==='Warning' }).length;
				}

				if(_eCnt>0){
						sap.m.MessageBox.error("Request contains error. Please review and fix before Submitting");
						_self.displayMessages(oMsg.results);
						return false;
				// } else if(_wCnt>0) {
					// 	sap.m.MessageBox.warning("There are some warnings in your request. You can still approve and process it, or cancel to review the warnings", {
					// 		actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					// 		emphasizedAction: sap.m.MessageBox.Action.OK,
					// 		onClose: function (sAction) {
					// 			if(sAction===sap.m.MessageBox.Action.OK) {
					// 				//  submit form for review
					// 			} else {
					// 				_self.displayMessages(oMsg.results);
					// 				return false;
					// 			}
					// 		},
					// 		dependentOn: this.getView()
					// 	});						
					// }

				} else {

					if (!this.oApproveDialog) {
						this.oApproveDialog = new sap.m.Dialog({
							// title: (_ctx.bHasServices)?"This request contains one or more service items":"Create Purchase Requisition",
							title: "Create Purchase Requisition",
							type: sap.m.DialogType.Message,
							content: [
								new sap.m.Text({
									// text: (_ctx.bHasServices)?"A Purchase Requisition (PR) must be created manually in P2P system using the SRM Shopping Cart process.\nPlease enter the resulting PR number in the request before clicking <Complete>. The request cannot be completed without this information.":"Do you want to create Purchase Requisition in P2P?",
									text: "Do you want to create Purchase Requisition in P2P?",
									wrapping: true
								}),
								// _sNote
							],
							beginButton: new sap.m.Button({
								type: sap.m.ButtonType.Emphasized,
								// text: (_ctx.bHasServices)?"Continue":"Create PR",
								text: "Create PR",
								press: function () {
									let _user = _self.getUser();
									let _mkey = _mdl.createKey("/HeaderSet", {
										PrqNo :  _ctx.PrqNo,
										Userid : _user.getId()
									});
						
									let _now = new Date();
															
									_mdl.setProperty(_mkey+'/Status', '032');

									controller.getOwnerComponent()._oErrorHandler._bMessageOpen = true;
		
									_mdl.submitChanges({
										success: function(oData){		
											_mdl.refresh(true);
										},
										error: function(oError){
											let _msg = JSON.parse(oError.responseText);
											sap.m.MessageBox.error(_msg.error.message.value);	
										}
									})
														
									this.oApproveDialog.close();
									this.oApproveDialog.destroy();
									this.oApproveDialog = null;
								}.bind(this)
							}),
							endButton: new sap.m.Button({
								text: "Cancel",
								press: function () {
									this.oApproveDialog.close();
									this.oApproveDialog.destroy();
									this.oApproveDialog = null;
								}.bind(this)
							})
						});
					}
		
					this.oApproveDialog.open();		


				}


			})
			.fail(function(oError){

			})	

		},

		onDisplayNotes: function(oEvent){
			if (!this.oNotesDisp) {
				this.createNotesPopover(oEvent);
			}
			this.oNotesDisp.open();

		},


		displayMessages: function(aMsg){
			let oButton = this.getView().byId('__validateMsg'),
				_mdl = this.getView().getModel(),
				_path = '',
				_pref = '',
				_sTarget = '';

			let _user = this.getUser();
			
			this.oMP.getBinding("items").attachChange(function(oEvent){
				this.oMP.navigateBack();
				oButton.setType(this.buttonTypeFormatter());
				oButton.setIcon(this.buttonIconFormatter());
				oButton.setText(this.highestSeverityMessages());
			}.bind(this));

			this._MessageManager.removeAllMessages();

			aMsg.forEach( (msg) => {
				switch(msg.Entity){
					case 'Header': 
						_path = _mdl.createKey('/HeaderSet',{
							'PrqNo': msg.Prrnr,
							'Userid': _user.getId()
						});
						break;
					case 'Item':
						_path = _mdl.createKey('/ItemSet',{
							'PrqNo': msg.Prrnr,
							'PrqItem': msg.Pritm,
							'CName' : _user.getId()
						});
						_pref = 'Line '+msg.Pritm+':';
						break;
					case 'ItemAcc':
						_path = _mdl.createKey('/ItemAccSet',{
							'PrqNo': msg.Prrnr,
							'PrqItem': msg.Pritm,
							'PrqItemAcc': msg.Seqno,
							'aUser' : _user.getId()
						});
						_pref = 'Line '+msg.Pritm+', Acc#'+msg.Seqno+':';
						break;
				}

				_sTarget = _path + '/' + msg.Property;

				// let oLink = new sap.m.Link({
				// 	text: "Show more information",
				// 	href: msg.Url,
				// 	target: "_blank"
				// });

				controller._MessageManager.addMessages(
					new Message({
						id: msg.Id,
						message: msg.Msgtext,
						type: msg.Type,
						additionalText: _pref+msg.Techdet,
						code: msg.Code,
						description: msg.Descr,
						descriptionUrl: msg.Url,
						target: _sTarget,
						processor: controller.getModel()
					})
				);

			})

			if(controller._MessageManager.getMessageModel().getData().length>0) {
				oButton.setVisible(true);
			}


			setTimeout(function(){
				if(oButton.getVisible()) this.oMP.openBy(oButton);
			}.bind(this), 100);

		},
		
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		// onSendEmailPress : function () {
		// 	var oViewModel = this.getModel("detailView");

		// 	URLHelper.triggerEmail(
		// 		null,
		// 		oViewModel.getProperty("/shareSendEmailSubject"),
		// 		oViewModel.getProperty("/shareSendEmailMessage")
		// 	);
		// },


		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		// onListUpdateFinished : function (oEvent) {
		// 	var sTitle,
		// 		fOrderTotal = 0,
		// 		iTotalItems = oEvent.getParameter("total"),
		// 		oViewModel = this.getModel("detailView"),
		// 		oItemsBinding = oEvent.getSource().getBinding("items"),
		// 		aItemsContext;

		// 	// only update the counter if the length is final
		// 	if (oItemsBinding.isLengthFinal()) {
		// 		if (iTotalItems) {
		// 			sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
		// 		} else {
		// 			//Display 'Line Items' instead of 'Line items (0)'
		// 			sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
		// 		}
		// 		oViewModel.setProperty("/lineItemListTitle", sTitle);

		// 		aItemsContext = oItemsBinding.getContexts();
		// 		fOrderTotal = aItemsContext.reduce(_calculateOrderTotal, 0);
		// 		oViewModel.setProperty("/totalOrderAmount", fOrderTotal);
		// 	}

		// },
		onDeleteReq: function(oEvent){
			let pp=oEvent.oSource.getBindingContext().getPath(),
				_mdl = oEvent.oSource.getModel();
			var _self = this;

			sap.m.MessageBox.warning("Are you sure you want to delete this request?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				emphasizedAction: sap.m.MessageBox.Action.OK,
				onClose: function (sAction) {
					if(sAction===sap.m.MessageBox.Action.YES) {
						_mdl.remove(pp, {
							success: function(oData){
								_self.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
								_self.getModel("appView").setProperty("/itemView", false);
								_self.getModel("appView").setProperty("/reqView", false);
					
								// No item should be selected on master after detail page is closed
								_self.getOwnerComponent().oListSelector.clearMasterListSelection();
								_self.getRouter().navTo("master");
				
								// _mdl.refresh(true);
							},
							error: function(oError, oResponse){
								_self._MessageManager.removeAllMessages();
								let _msg = JSON.parse(oError.responseText);
								sap.m.MessageBox.error(_msg.error.message.value);		
							}
			
						})
					}
				},
				dependentOn: this.getView()
			});						



		},

		onDupReq: function(oEvent){
			let _ctx=oEvent.oSource.getBindingContext().getObject(),
				_user = this.getUser(),						
				_mdl = oEvent.oSource.getModel();
			var _self = this;

			sap.m.MessageBox.warning("Create a copy of this request?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				emphasizedAction: sap.m.MessageBox.Action.OK,
				onClose: function (sAction) {
					if(sAction===sap.m.MessageBox.Action.YES) {

						let _vData = {
							PrrNo: _ctx.PrqNo,
							Uname: _user.getId()
						};
			
						_mdl.callFunction("/duplicateRequest", {
							urlParameters : _vData,
							success : function(oData, response) {
								if(oData.Type==='Error' && !oData.Prrnr){
									sap.m.MessageToast.show(oData.Msgtext)
								} else {
									_mdl.refresh(true)
									_self.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
									_self.getModel("appView").setProperty("/itemView", false);
									_self.getModel("appView").setProperty("/reqView", false);
									sap.m.MessageToast.show('New Request '+oData.Prrnr+' was created');						
									// No item should be selected on master after detail page is closed
									_self.getOwnerComponent().oListSelector.clearMasterListSelection();
									// _self.getRouter().navTo("object", {
									// 	objectId: oData.Prrnr,
									// 	query: {
									// 		tab: "itemList"
									// 	}
									// }, true);										
								}
				
							},
							error : function(oError) {
								_self._MessageManager.removeAllMessages();
								let _msg = JSON.parse(oError.responseText);
								sap.m.MessageBox.error(_msg.error.message.value);		
							},
						});
		

					}
				},
				dependentOn: this.getView()
			});						



		},

		// onCreateNewReqItem: function(oEvent){
		// 	let _head = this.getView().getBindingContext().getObject();
		// 	let _user = this.getUser();
		// 	let _newData = {};
		// 	let _cTab = this.getView().byId('lineItemsList');
		// 	let oItemsBinding = _cTab.getBinding("rows");
		// 	let _self = this;
		// 	let _nextItem = 0;

		// 	var padWithLeadingZeros=function(num, totalLength) {
		// 		return String(num).padStart(totalLength, '0');
		// 	}
		// 	_cTab.getBinding('rows').getContexts().forEach((rr) => {
		// 		_nextItem = Math.max(_nextItem,parseInt(rr.getObject().PrqItem))
		// 	})

		// 	// call Function Import to generate New blank row
		// 	_newData.PrqNo = _head.PrqNo;
		// 	_newData.CName = _user.getId();
		// 	_newData.bMaterial = false;
		// 	// _newData.ItemType = 'P';
		// 	// _newData.ItemTypeText = 'Product';
		// 	_newData.Menge = "0.0";
		// 	_newData.Preis = "0.0";
		// 	_newData.Curr = 'USD';
		// 	_newData.bEkgrpUseDef = (!!_head.PurchGrp)?true:false;
		// 	// _newData.Meins = 'EA';
		// 	_newData.bNewMaterial = false;
		// 	_newData.bSoftware = false;
		// 	_newData.bEditable = true;
		// 	_newData.PrqItem = padWithLeadingZeros(_nextItem+1, 3);

		// 	_newData.bSplit = false;
		// 	_newData.bWBS = false;
		// 	_newData.bCC = false;
		// 	_newData.bGL = false;
		// 	_newData.bHazmat= false;
		// 	_newData.bForeign = false;
		// 	_newData.bInspect= false;
		// 	_newData.bInvApprUseDef= true;
		// 	// _newData.bEkgrpUseDef= true;

		// 	_newData.bApprove = false;


		// 	oItemsBinding.create(_newData, true, {inactive : false})


		// },

		// onItemDetail: function(oEvent){
		// 	let _self = this;

		// 	var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
		// 		__path = oEvent.oSource.getBindingContext().getPath(),
		// 		__item = oEvent.oSource.getBindingContext().getObject();
		// 		// supplier = __path.split("/").slice(-1).pop();
	
		// 	this.getModel("appView").setProperty("/layout", oNextUIState.layout);
		// 	this.getModel("appView").setProperty("/itemView", true);
	
		// 	this.getOwnerComponent().setModel(new JSONModel(__item),'item');
	
		// 	this.oRouter.navTo("objectItem", {
		// 		objectId: __item.PrqNo, 
		// 		itemId: __item.PrqItem
		// 	});
	
		
		// },

		// onItemSelect: function(oEvent){

		// if(oEvent.oSource.getSelectionMode()==='Single'){
		// 	var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
		// 	__path = oEvent.oSource.getBindingContext().getPath(),
		// 	__item =oEvent.getParameter('rowContext').getObject();
		// 	// supplier = __path.split("/").slice(-1).pop();

		// this.getModel("appView").setProperty("/layout", oNextUIState.layout);
		// this.getModel("appView").setProperty("/itemView", true);

		// this.getOwnerComponent().setModel(new JSONModel(__item),'item');

		// this.oRouter.navTo("objectItem", {
		// 	objectId: __item.PrqNo, 
		// 	itemId: __item.PrqItem
		// });


		// }
		// },

		// handleChange(oEvent){
		// 	let _ctx = oEvent.oSource.getBindingContext(),
		// 		_mdl = _ctx.oModel,
		// 		_sp  = _ctx.sPath;

		// 	let _from = new Date(oEvent.getParameter('from')).YYYYMMDD(),
		// 		_to = new Date(oEvent.getParameter('to')).YYYYMMDD();

		// 	_mdl.setProperty(_sp+'/PipStart',_from);
		// 	_mdl.setProperty(_sp+'/PipEnd',_to);

		// 	_mdl.refresh(true);

		// },

		// onSaveItems: function(oEvent){
		// 	let _mdl = this.getModel();

		// 	if(_mdl.hasPendingChanges()) {
		// 		_mdl.submitChanges({
		// 			success: function(oData){
		// 				_mdl.refresh(true);
		// 			},
		// 			error: function(oError){
		// 				let _msg = JSON.parse(oError.responseText);
		// 				sap.m.MessageBox.error(_msg.error.message.value);	
		// 			}
		// 		})
		// 	}

		// },

		// onChargeCodeSuggest: function (oEvent) {
		// 	let _user = this.getUser();
		// 	let _mdl = oEvent.oSource.getBindingContext().oModel,
		// 		_prq = oEvent.oSource.getBindingContext().getObject(),
		// 		_key = _mdl.createKey('/HeaderSet',{'PrqNo':_prq.PrqNo, 'Userid': _user.getId()}),
		// 		_pl = _mdl.getProperty(_key+'/Plant');

		// 	var sTerm = oEvent.getParameter("suggestValue");
		// 	var aFilters = [];
		// 	if (sTerm) {
		// 		aFilters.push(new Filter("ZlDesc", FilterOperator.StartsWith, sTerm));
		// 		aFilters.push(new Filter("ZlSite", FilterOperator.EQ, _pl));
		// 		aFilters.push(new Filter("ZlSrc", FilterOperator.EQ, 'CC'));
		// 	}

		// 	oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
		// },



		// onChargeCodeChange: function(oEvent){
		// 	let _user = this.getUser();
		// 	let _ctx = oEvent.oSource.getBindingContext(),
		// 		_self = this,
		// 		_sp = _ctx.sPath,
		// 		_val = oEvent.oSource.getValue(),
		// 		_prq = oEvent.oSource.getBindingContext().getObject(),
		// 		_mdl = _ctx.oModel,
		// 		_key = _mdl.createKey('/HeaderSet',{'PrqNo':_prq.PrqNo, 'Userid':_user.getId()}),
		// 		_pl = _mdl.getProperty(_key+'/Plant');


		// 	let _mKey = _mdl.createKey('/ChargeCodeSet',{
		// 		ZlFrom: _val,
		// 		ZlSite: _pl
		// 	})

		// 	_mdl.read(_mKey,{
		// 		success: function(oData){
		// 			if(!!oData.ZlFrom){
		// 				_mdl.setProperty(_sp+'/ChargeNum',oData.ZlFrom);
		// 				// _mdl.setProperty(_sp+'/Contract',oData.ZlPrimCont);
		// 			} else {
		// 				_mdl.setProperty(_sp+'/ChargeNum','');
		// 				// _mdl.setProperty(_sp+'/Contract','');
		// 			}
		// 		},

		// 		error: function(oData){
		// 			_mdl.setProperty(_sp+'/ChargeNum','');
		// 			// _mdl.setProperty(_sp+'/Contract','');
		// 		}
		// 	})


		// },

		// onItemCopy: function(oEvent){
		// 	let _self = this;
		// 	let _key = oEvent.oSource.getBindingContext().sPath;
		// 	let _obj = oEvent.oSource.getBindingContext().getObject();
		// 	let _newData = {};
		// 	let _cTab = this.getView().byId('lineItemsList');
		// 	let oItemsBinding = _cTab.getBinding("rows");
		// 	let _nextItem = 0;

		// 	var padWithLeadingZeros=function(num, totalLength) {
		// 		return String(num).padStart(totalLength, '0');
		// 	}

		// 	_cTab.getBinding('rows').getContexts().forEach((rr) => {
		// 		_nextItem = Math.max(_nextItem,parseInt(rr.getObject().PrqItem))
		// 	})

		// 	Object.keys(_obj).forEach((_k) => { 
		// 		_newData[_k] = (_obj[_k] instanceof Date)? _obj[_k].YYYYMMDD() :_obj[_k];
		// 	})

		// 	_newData.PrqItem = padWithLeadingZeros(_nextItem+1, 3);
		// 	if(_newData.bSplit){
		// 		_newData.Category = '';
		// 		_newData.CostCenter = '';
		// 		_newData.GLAcc = '';
		// 		_newData.bSplit = false;
		// 		_newData.bWBS = false;
		// 		_newData.bCC = false;	
		// 	}
		// 	_newData.aName = '';
		// 	_newData.aDate = '';
		// 	_newData.aNote = '';
		// 	_newData.aSmtp = '';
		// 	_newData.aStatus = '';
		// 	_newData.aTime = '';
		// 	_newData.aUser = '';

		// 	oItemsBinding.create(_newData, true, {inactive : false})

		// 	// oEvent.oSource.getModel().remove(_key, {
		// 	// 	success: function(oData){
		// 	// 		_self.getModel().refresh(true);
		// 	// 	},
		// 	// 	error: function(oError, oResponse){
		// 	// 		let _msg = JSON.parse(oError.responseText);
		// 	// 		sap.m.MessageBox.error(_msg.error.message.value);
		// 	// 	}
		// 	// })

		// },

		// onItemDelete: function(oEvent){
		// 	let _self = this;
		// 	let _key = oEvent.oSource.getBindingContext().sPath;
		// 	let _model = oEvent.oSource.getModel();

		// 	let _cc = Object.keys(_model.getPendingChanges()).find((a) => { return '/'+a===_key})

		// 	if(!!_cc) {
		// 		_model.resetChanges([_key], true, true)
		// 		.then(function(oRet){
		// 			_self.getModel().refresh(true);
		// 		})
		// 	} else {
		// 		oEvent.oSource.getModel().remove(_key, {
		// 			success: function(oData){
		// 				_self.getModel().refresh(true);
		// 			},
		// 			error: function(oError, oResponse){
		// 				let _msg = JSON.parse(oError.responseText);
		// 				sap.m.MessageBox.error(_msg.error.message.value);
		// 			}
		// 		})	
		// 	}

		// },

		// onChargeCodeSelected: function(oEvent){

		// },

		// onOptionsChange: function(oEvent){

		// 	let _mdl = oEvent.oSource.getModel(),
		// 		_sPath = oEvent.oSource.getBindingContext().sPath,
		// 		_data = oEvent.oSource.getBindingContext().getObject();
	
		// 	if(!_data.bMaterial) {
		// 		// _mdl.setProperty(_sPath+'/bOverLimit',false);
		// 		_mdl.setProperty(_sPath+'/bDeliverable',false);
		// 		_mdl.setProperty(_sPath+'/bLMuse',false);
		// 	}
	
		// 	// if(!_data.bOverLimit) {
		// 	// 	_mdl.setProperty(_sPath+'/bDeliverable',false);
		// 	// 	_mdl.setProperty(_sPath+'/bLMuse',false);
		// 	// }
	
		// 	if(!_data.bDeliverable) {
		// 		_mdl.setProperty(_sPath+'/bLMuse',false);
		// 	}
	
		// },
	

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched : function (oEvent) {

			let _user = this.getUser();
			let _mdl = this.getModel('detailView');
			let _ctx = this.getView().getBindingContext();
			let _vData = (!!_ctx)?_ctx.getObject():null;
			let _mBtn = this.getView().byId('__statusMenu');
			
			// let _w = _mBtn.$().width();
			if(!!_mBtn){
				_mBtn.setMenu(false);
				let _menu = (!!_vData)?this.getStatusMenu(_vData.Status):false;
				if(!!_menu){
					_mBtn.setMenu(_menu);
				}
			}
			


			this._MessageManager.removeAllMessages();

			this.valBtn = this.getView().byId('__validateMsg');
			this._cc = this.byId('_chargeCode');
			_mdl.setProperty('/selMode',sap.ui.table.SelectionMode.None);
			_mdl.setProperty('/itemDelMode',false);

			_mdl.refresh(true);

			var oArguments = oEvent.getParameter("arguments");
			this._sObjectId = oArguments.objectId;
			// Don't show two columns when in full screen mode
			if (this.getModel("appView").getProperty("/layout") !== "MidColumnFullScreen") {
				this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			}
			this.getModel().metadataLoaded().then( function() {
				var sObjectPath = this.getModel().createKey("HeaderSet", {
					PrqNo :  this._sObjectId,
					Userid : _user.getId()
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
			var oQuery = oArguments["?query"];
			if (oQuery && this._aValidKeys.indexOf(oQuery.tab) >= 0){
				this.getView().getModel("detailView").setProperty("/selectedTab", oQuery.tab);
				this.getRouter().getTargets().display(oQuery.tab);
			} else {
				this.getRouter().navTo("object", {
					objectId: this._sObjectId,
					query: {
						tab: "itemList"
					}
				}, true);
			}
		},


		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView : function (sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path : sObjectPath,
				// parameters: {
				// 	expand: "Customer,Order_Details/Product,Employee"
				// },
				events: {
					change : this._onBindingChange.bind(this),
					dataRequested : function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						let _ctx = this.getBoundContext();
						let _vData = (!!_ctx)?_ctx.getObject():null;
						let _mBtn = controller.getView().byId('__statusMenu');
						if(!!_mBtn){
							_mBtn.setMenu(false);
							let _menu = (!!_vData)?controller.getStatusMenu(_vData.Status):false;
							if(!!_menu){
								_mBtn.setMenu(_menu);
							}
						}
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		// deleteSelectedItems: function(oEvent){
		// 	let _selInd = this.byId("lineItemsList").getSelectedIndices();
		// 	let _self = this;
		// 	let _mdl = this.getModel();

		// 	let _rows = [];

		// 	this.byId("lineItemsList").getSelectedIndices().forEach((ii)=>{
		// 		if(_self.byId("lineItemsList").getContextByIndex(ii)){
		// 			_rows.push(_self.byId("lineItemsList").getContextByIndex(ii).getObject());
		// 		}			
		// 	})

		// 	this.deleteItems({Data:_rows})
		// 		.done(function(oData){
		// 			_mdl.refresh(true);
		// 		})
		// },

		// deleteItems: function (param, oContext) {
		// 	var _p = param || {};
		// 	var _self = this;
		// 	let _mdl = this.getModel();
		// 	var _promise = _p.Promise || $.Deferred();
		// 	var _data = (_p)?_p.Data||{}:{};
		// 	let _user = this.getUser();

		// 	var f_delete = function(oItem,oPromise){
		// 		let _pp = oPromise || $.Deferred();

		// 		var key = _mdl.createKey("/ItemSet", {
		// 			"PrqNo": oItem.PrqNo,
		// 			"PrqItem": oItem.PrqItem,
		// 			"CName" : _user.getId()
		// 		});

		// 		_mdl.remove(key,
		// 			{
		// 				success: function (data) {
		// 					_pp.resolve(data);
		// 				},
		// 				error: function (error) {
		// 					_pp.reject(error);
		// 				}
		// 			}
		// 		);

		// 		return _pp;
		// 	};

		// 	var _delWIUser = [];

		// 	_data.forEach(function(oItem){
		// 		var _p = $.Deferred();
		// 		_delWIUser.push(f_delete(oItem,_p));
		// 	})

		// 	$.when.apply($, _delWIUser).then(function (data) {
		// 		_promise.resolve(data);
		// 	})

		// 	return _promise;
		// },

		_onBindingChange : function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.PrqNo,
				sObjectName = oObject.PrqNo,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			// oViewModel.setProperty("/shareSendEmailSubject",
			// 	oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			// oViewModel.setProperty("/shareSendEmailMessage",
			// 	oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href, oObject.ShipName, oObject.EmployeeID, oObject.CustomerID]));
		},

		_onMetadataLoaded : function () {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");
				// oLineItemTable = this.byId("lineItemsList"),
				// iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

			// oLineItemTable.attachEventOnce("updateFinished", function() {
			// 	// Restore original busy indicator delay for line item table
			// 	oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
			// });

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		onTabSelect : function(oEvent){
			var sSelectedTab = oEvent.getParameter("selectedKey");

			if(this._aValidKeys.indexOf(sSelectedTab) >= 0) {
				this.getRouter().navTo("object", {
					objectId: this._sObjectId,
					query: {
						tab: sSelectedTab
					}
				}, true);// true without history
	
			}


		},

		// handleItemPress: function (oEvent) {
		// 	var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
		// 		__path = oEvent.oSource.getBindingContext().getPath(),
		// 		__item = oEvent.getParameter('listItem').getBindingContext().getObject();
		// 		// supplier = __path.split("/").slice(-1).pop();

		// 	this.getModel("appView").setProperty("/layout", oNextUIState.layout);

		// 	this.getOwnerComponent().setModel(new JSONModel(__item),'item');

		// 	this.oRouter.navTo("objectItem", {
		// 		objectId: __item.PrqNo, 
		// 		itemId: __item.PrqItem
		// 	});
		// },


		toggleFullScreen: function () {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout",  this.getModel("appView").getProperty("/previousLayout"));
			}

		},

		_submitRequest: function(oContext){
			
			let _ctx = oContext.getObject(),
				_mdl = oContext.oModel;

			let _user = this.getUser();		
			let _self = this;	
			

			var _sNote = new sap.m.TextArea({
				width: "100%",
				placeholder: "Add note for PR Reviewer"
			});

			if (!this.oSubmitDialog) {
				this.oSubmitDialog = new sap.m.Dialog({
					title: "Submit Purchase Request",
					type: sap.m.DialogType.Message,
					content: [
						new sap.m.Label({
							text: "Do you want to submit this request?",
							labelFor: _sNote.getId()
						}),
						_sNote
					],
					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "Submit",
						press: function () {
							let _user = _self.getUser();
							let _mkey = _mdl.createKey("/HeaderSet", {
								PrqNo :  _ctx.PrqNo,
								Userid :  _user.getId()
							});
				
							let sText = _sNote.getValue();
							let _now = new Date();
							
							_mdl.createEntry('/NotesSet',{
								properties:{
									'Prrnr':_ctx.PrqNo,
									'Crtdat':_now.YYYYMMDD(),
									'Crtime':_now.toLocaleTimeString('en-US', { hourCycle: 'h24' }),
									'Crtnam':_user.getId(),
									'Note': sText
								}
							})				
				
							_mdl.setProperty(_mkey+'/Status', '008');
							// _mdl.setProperty(_mkey+'/Inputter', '');

							_mdl.submitChanges({
								success: function(oData){		
										_mdl.refresh(true);
									},
									error: function(oError){
										let _msg = JSON.parse(oError.responseText);
										sap.m.MessageBox.error(_msg.error.message.value);	
									}
								})

							this.oSubmitDialog.close();
							this.oSubmitDialog.destroy();
							this.oSubmitDialog = null;

						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							this.oSubmitDialog.close();
							this.oSubmitDialog.destroy();
							this.oSubmitDialog = null;
						}.bind(this)
					})
				});
			}

			this.oSubmitDialog.open();

			// _mdl.setProperty(_mkey+'/Status', '008');

			// _mdl.submitChanges({
			// 	success: function(oData){
			// 		_mdl.refresh(true);
			// 	},
			// 	error: function(oError){
			// 		let _msg = JSON.parse(oError.responseText);
			// 		sap.m.MessageBox.error(_msg.error.message.value);	
			// 	}
			// })


		},

		onCloseDetailPress: function (oEvent) {
			// let _mdl = this.getModel();
			// let _self = this;
			// let _cTab = controller.getView().byId('lineItemsList');
			// let oItemsBinding = _cTab.getBinding("rows");

			let _editMode = this.getModel("appView").getProperty("/editMode");

			if(!!_editMode){
				this._cancelEdit(oEvent)	
				.done(function(oRes){
					// oItemsBinding.refresh(true);
					// _cTab.refreshRows('Filter');
					// _mdl.refresh(true);
				})
				.fail(function(oErr){

				})
			} else {
				this.closeMultiSelection();
				this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
				this.getModel("appView").setProperty("/itemView", false);
				this.getModel("appView").setProperty("/reqView", false);
	
				// No item should be selected on master after detail page is closed
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				this.getRouter().navTo("master");
	
			}

		},

		// enableItemMutiSelection: function (oEvent) {
		// 	let _mdl = this.getModel('detailView');
		// 	let _mode = _mdl.getProperty('/selMode');

		// 	if (sap.ui.table.SelectionMode.None === _mode) {
		// 	// if (sap.ui.table.SelectionMode.Single === this.byId("lineItemsList").getSelectionMode()) {
		// 		this._doCloseItemDetail();
		// 		_mdl.setProperty('/selMode',sap.ui.table.SelectionMode.MultiToggle);
		// 		_mdl.setProperty('/itemDelMode',true);
		// 		// this.byId("lineItemsList").setSelectionMode(sap.ui.table.SelectionMode.MultiToggle);
		// 		// this.byId("__itemMultiDelete").setVisible(true);
		// 	} else {
		// 		_mdl.setProperty('/selMode',sap.ui.table.SelectionMode.None);
		// 		_mdl.setProperty('/itemDelMode',false);
		// 		// this.byId("lineItemsList").setSelectionMode(sap.ui.table.SelectionMode.Single);
		// 		// this.byId("__itemMultiDelete").setVisible(false);
		// 	}
		// 	_mdl.refresh(true);
		// },

		// disableItemMutiSelection: function (oEvent) {
		// 	let _mdl = this.getModel('detailView');

		// 	_mdl.setProperty('/selMode',sap.ui.table.SelectionMode.None);
		// 	_mdl.setProperty('/itemDelMode',false);

		// 	_mdl.refresh(true);

		// 	// this.byId("lineItemsList").setSelectionMode(sap.ui.table.SelectionMode.Single);
		// 	// this.byId("__itemMultiDelete").setVisible(false);
		// },

		onAfterRendering: function(oEvent){
			// let _mBtn = this.getView().byId('__statusMenu');
			// if(!!_mBtn){
			// 	let _w = _mBtn.$().width();

			// 	setTimeout(() => {
			// 		let _menu = _mBtn.getMenu();
			// 		}, 0);		
	
			// }


		},

		onBeforeMenuOpen: function(oEvent){

		},
		getStatusMenu: function(status){
			
			if (!status) return false;
			let _self = this;
			let _app = this.getModel('appView').oData;
			let _req = this.getView().getBindingContext().getObject();

			let _menu = new sap.m.Menu();
			let _item;

			switch(status){
				case '002': //New
				case '004': // Rejected
					_item = new sap.m.MenuItem({
						text: {
							parts: [
								{path: 'bEditable'},
								{path: 'bRReview'},
								{path: 'bCCApprove'},
								{path: 'appView>/opmode'}
							],
							formatter: formatter.SubmitBtnTitle
						},
						icon: 'sap-icon://accept',
						visible:{
							parts: [
								{path: 'appView>/editMode'},
								{path: 'bEditable'},
								{path: 'bReview'},
								{path: 'appView>/opmode'}
							],
							formatter: formatter.SubmitBtnVisible
						},
						press: function(oEvent){
							_self.onSubmitRequest(oEvent);
						}
					});
					_menu.addItem(_item);
					if(!!_req.bEditable && _app.opmode===''){
						_item = new sap.m.MenuItem({
							text: 'Validate',
							icon: 'sap-icon://validate',
							press: function(oEvent){
								_self.onReqValidate(oEvent);
							}
						});
						_menu.addItem(_item);	
					}
					return _menu;
					break;	
				case '008': // Submitted
					// _item = new sap.m.MenuItem({
					// 	text: 'Re-Submit',
					// 	icon: 'sap-icon://accept',
					// 	visible:{
					// 		parts: [
					// 			{path: 'appView>/editMode'},
					// 			{path: 'bEditable'},
					// 			{path: 'bReview'},
					// 			{path: 'appView>/opmode'}
					// 		],
					// 		formatter: formatter.SubmitBtnVisible
					// 	},
					// 	press: function(oEvent){
					// 		_self.onSubmitRequest(oEvent);
					// 	}
					// });
					// _menu.addItem(_item);
					
					_item = new sap.m.MenuItem({
						text: 'Review',
						icon: 'sap-icon://workflow-tasks',
						visible:{
							parts: [
								{path: 'appView>/editMode'},
								{path: 'bEditable'},
								{path: 'bReview'},
								{path: 'appView>/opmode'}
							],
							formatter: formatter.ReviewBtnVisible
						},
						press: function(oEvent){
							_self.onSubmitRequest(oEvent);
						}
					});
					_menu.addItem(_item);

					if(!!_req.bEditable && _app.opmode===''){

						_item = new sap.m.MenuItem({
							text: 'Validate',
							icon: 'sap-icon://validate',
							press: function(oEvent){
								_self.onReqValidate(oEvent);
							}
						});
						_menu.addItem(_item);	
					}
					return _menu;
					break;	
				case '016': // Submitted
					_item = new sap.m.MenuItem({
						text: 'Approve',
						icon: 'sap-icon://accept',
						visible: {
							parts:[
								{path: 'appView>/opmode'},
								{path: 'bApprove'}
							],
							formatter:formatter.postBtnVisible
						},
						press: function(oEvent){
							_self.onPostRequest(oEvent);
						}
					});
					_menu.addItem(_item);

					_item = new sap.m.MenuItem({
						text: 'Reject',
						icon: 'sap-icon://decline',
						visible: {
							parts:[
								{path: 'appView>/opmode'},
								{path: 'bApprove'}
							],
							formatter:formatter.postBtnVisible,
						},
						press: function(oEvent){
							_self.onRejectRequest(oEvent);
						}
					});
					_menu.addItem(_item);

					if(!!_req.bEditable && _app.opmode===''){
						_item = new sap.m.MenuItem({
							text: 'Validate',
							icon: 'sap-icon://validate',
							press: function(oEvent){
								_self.onReqValidate(oEvent);
							}
						});
						_menu.addItem(_item);	
					};

					_item = new sap.m.MenuItem({
						text: 'Reassign',
						icon: 'sap-icon://undo',
						visible: {
							parts:[
								{path: 'appView>/opmode'},
								{path: 'bApprove'}
							],
							formatter:function(sMode,bApprove){
								if(sMode==='A' && !!bApprove) {
									return true;
								} else {
									return false;
								}					
							},
						},
						press: function(oEvent){
							_self.onReturnRequest(oEvent);
						}
					});
					_menu.addItem(_item);	
					return _menu;
					break;	
				case '032': // Success
				case '064': // Completed
				case '512': // Archived
					return false;
				default: return false;;
			}

			return _menu;

		},


	});
});