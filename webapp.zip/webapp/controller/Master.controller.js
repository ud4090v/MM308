sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter",
	"sap/ui/core/format/DateFormat"
], function (BaseController, JSONModel, Filter, FilterOperator, Sorter, GroupHeaderListItem, Device, Fragment, formatter, DateFormat) {
	"use strict";

	var controller;

	return BaseController.extend("lmco.ces.preq.controller.Master", {

		formatter: formatter,
		
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		selectedReq: null,
		onInit : function () {
			// Control state model
			let _user = sap.ushell.Container.getService('UserInfo'),
				_app = this.getOwnerComponent().getModel('appView');
			var oList = this.byId("__preqList"),
				oViewModel = this._createViewModel(),
				oFltModel = this._createFilterModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			let _self = this;
			let _mdl = this.getOwnerComponent().getModel("appView")

			// let _key = this.getModel().createKey('/ContextSet',{'User':_user.getId()});


			this._oGroupFunctions = {
				Status: function (oContext) {
					var sStatus = oContext.getProperty("Status"),
						sText = oContext.getProperty("StatusText");
					return {
						key: sStatus,
						text: sText
					};
				},

				Plant: function (oContext) {
					var sKey = oContext.getProperty("Plant"),
						sText = oContext.getProperty("PlantName");
					return {
						key: sKey,
						text: sText
					};
				},

				CDat: function (oContext) {
					var oDate = oContext.getProperty("CDat"),
						_dt = new Date(oDate);
						// iYear = _dt.getFullYear(),
						// iMonth = _dt.getMonth() + 1,
						// sMonthName = this._oMonthNameFormat.format(_dt);

					return {
						key: oDate,
						text: _dt.toLocaleDateString()
					};
				}.bind(this)

			};
			this._oMonthNameFormat = DateFormat.getInstance({ pattern: "MMMM"});

			this._oList = oList;

			// keeps the filter and search state
			this._oListFilterState = {
				aFilter : [],
				aSearch : []
			};

			this.setModel(oViewModel, "masterView");
			this.setModel(oFltModel, "flt");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function(){
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			let _tabs = this.byId('masterTabBar');
			let _approveMode = _mdl.oData.approveMode;
			if(_mdl.oData.approveMode){
				let _mtab = _tabs.getItems().find((tt) => {
					return tt.getKey()==='mylist'
				});
				_mdl.setProperty("/opmode", "A");
				if(!!_mtab) _mtab.setVisible(false);
				_tabs.setSelectedKey('review');
			} else {
				let _aTabs = _tabs.getItems();
				_mdl.setProperty("/opmode", "");
				_aTabs.forEach((tt) => {
					if(tt.getKey()==='review' || tt.getKey()==='submitted') {
						tt.setVisible(false);
					}
				});
				_tabs.setSelectedKey('mylist');
			}

			let _key = "/ContextSet(User='"+_user.getId()+"',Mode='')"

		
			// this.getOwnerComponent().getModel().read(_key, {
			// 	success: function(oData) {
			// 		_app.setProperty('/iApprCnt',oData.iApprCnt.toString());
			// 		_app.setProperty('/iSubmitCnt',oData.iSubmitCnt.toString());
			// 		_app.setProperty('/iHistCnt',oData.iHistCnt.toString());
			// 		_app.setProperty('/iCnt',oData.iCnt.toString());
			// 		_mdl.setProperty('/debugUser',oData.DebugUser);
			// 		_mdl.setProperty('/useDebug',(!!oData.DebugUser)?true:false);											
			// 		_app.refresh(true);

			// 		_self.getRouter().getRoute("master").attachPatternMatched(_self._onMasterMatched, _self);
			// 		_self.getRouter().attachBypassed(_self.onBypassed, _self);
		
			// 	},
			// 	fail: function(oError){
			// 	}
			// }, this);

			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);


		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished : function (oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch : function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");

			if (sQuery) {
				this._oListFilterState.aSearch = [new Filter("PreqText", FilterOperator.Contains, sQuery)];
			} else {
				this._oListFilterState.aSearch = [];
			}
			this._applyFilterSearch();

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh : function () {
			this._oList.getBinding("items").refresh();
		},

		
		/**
		 * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onCreateNewRequest: function(oEvent) {
			let _self = this;
			let _user = this.getUser();
			controller = this;

			this.getModel().read("/PlantSet", {
				filters:[ new Filter("Uname", FilterOperator.EQ, _user.getId() ) ],
				success: function(oData) {
					let _mdl = new JSONModel(oData.results);

					let	_oNew = new lmco.ces.core.newPRR({
						allowServices: true,
						sites: {
							path: 'pl>/',
							text: '{pl>Name}',
							key:  '{pl>PlantID}',
							dcma: '{pl>DCMA}'
						},
						completed: function(oEvent){
							let _data = oEvent.getParameter('answers');
		
							_self._onCreateNewReq(_data);

							// if((_data.hwdeliverable && !_data.lmuse) || _data.Foreign){
							// 	sap.m.MessageBox.error("DO NOT proceed with this form. COS/SAP must be used according to MM-2-001 MMAS.", {
							// 		title: 'Caution!'
							// 	});						
							// } else {
							// 	_self._onCreateNewReq(_data);
							// }
						}
					});
					_self.getView().addDependent(_oNew);
					_oNew.setModel(_mdl,'pl');
					_oNew.open();
		
				},
				// filters: [new Filter('DCMA','EQ',true)]
			});

		},

		_onCreateNewReq: function(oData){
			let _user = this.getUser();
			let _newData = {};

			let _mdl = new JSONModel(_newData);

			let _mKey = this.getModel().createKey('/EwpSet',{
				NTID: _user.getId()
			})


			if(oData){
				_newData.Plant = oData.Plant;
				_newData.UnloadPoint = oData.UnloadPoint;
				_newData.PlantName = oData.PlantName;
				_newData.DCMA = !!oData.DCMA_Cert;
				_newData.PurchGrp = oData.Ekgrp;
				_newData.PurchGrpName = oData.Eknam;
				_newData.NoteBuyer = '';
				_newData.ShipNote = '';
				// _newData.bMaterial = !!oData.bMaterial;
				_newData.bOverLimit = false;
				// _newData.bDeliverable = !!oData.hwdeliverable;
				// _newData.bLMuse = !!oData.lmuse;
				_newData.PreqName = oData.cartNameSuffix;
				_newData.City = oData.shipCity;
				_newData.Pstlz = oData.shipPostalCode1;
				_newData.POBox = oData.shipPOBox;
				_newData.Street = oData.shipStreet;
				_newData.HouseNo = oData.shipHouseNo;
				_newData.Locat = oData.shipStreet2;
				_newData.Building = oData.shipBuilding;
				_newData.Floor = oData.shipFloor;
				_newData.RoomNo = oData.shipRoomNo;
				_newData.Country = oData.Country;
				_newData.State = oData.shipRegion;
				_newData.TelNumber = oData.TelNumbr;
				_newData.bForeign = false;
				_newData.bHazmat = false;
				_newData.bRepair = false;
				_newData.Inputter = '';
				_newData.InputterName = '';
				_newData.Bukrs = oData.Bukrs;
				_newData.Butxt = oData.Butxt;
				_newData.CName = _user.getId();
				_newData.CNameFull = _user.getFullName();
				_newData.CNameEmail = _user.getEmail();
				_newData.Recipient = _user.getId();
				_newData.RecName = _user.getFullName();1
				_newData.RecEmail = _user.getEmail();
				_newData.bSetReviewer = oData.bSetReviewer;
	}

			this.getModel().read(_mKey,{
				success: function(oData){
					if(!!oData.NTID){
						_newData.Recipient = oData.NTID;
						_newData.RecName = oData.Gal.substr(0,30);
						_newData.RecTel = oData.PrimaryPhone;
						_newData.RecEmail = oData.Email;
					} else {
						_newData.Recipient = _user.getId();
						_newData.RecName = _user.getFullName();
						_newData.RecEmail = _user.getEmail();
					}
					_mdl.refresh(true);
				},
				error: function(oData){
					_newData.Recipient = _user.getId();
					_newData.RecName = _user.getFullName();
					_newData.RecEmail = _user.getEmail();
					_mdl.refresh(true);
				}
			})

			// _mdl.refresh(true);


			this._newDlg = sap.ui.xmlfragment("__newRequestDlg", "lmco.ces.preq.view.fragments.CreateNewRequest", this)

			// this.getModel().resetChanges();

			this.getView().addDependent(this._newDlg);
			this._newDlg.setModel(_mdl,'mHdr');
			this._newDlg.setModel(this.getModel());
			this._newDlg.open();

		},

		applyMasterFilter: function(oEvent){
			let _flt = this.getModel('flt'),
				_inputter = _flt.getProperty('/reviewer');

			let _user = this.getUser();

			let aFilters = [
				new Filter('CName', 'EQ', this.getUser().getId()),
				new Filter('Opmode', 'EQ', 'S')
			]
	
			if(!!_inputter) aFilters.push(new Filter('Inputter', 'EQ', _inputter));

			this._oList.getBinding("items").aApplicationFilters = []

			this._oList.getBinding("items").filter(aFilters);

		},

		onHdrReviewerSuggest: function (oEvent) {
			let _user = this.getUser();
			let _mdl = oEvent.oSource.getModel('mHdr'),
				_prq = _mdl.oData,
				_pl = _prq.Plant;

			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("Gal", FilterOperator.Contains, sTerm));
				aFilters.push(new Filter("Plant", FilterOperator.EQ, _pl));
				aFilters.push(new Filter("Ntid", FilterOperator.EQ, _user.getId()));
			}

			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
		},

		onHdrReviewerSelected: function(oEvent){
			let _mdl = oEvent.oSource.getModel('mHdr');
			let _control = oEvent.oSource;
			let _val = oEvent.oSource.getValue(),
				sRow = oEvent.getParameter('selectedRow');			

			let sObj = (!!sRow)?sRow.getBindingContext().getObject():null,
			    sKey = (!!sObj)?sObj.Ntid:_val,
				sTxt = (!!sObj)?sObj.Gal:_val;

			

			if(!sKey) return;

			_mdl.setProperty('/Inputter',sKey);
			_mdl.setProperty('/InputterName',sTxt);

			// _control.setValue(sObj.Gal);	
			_control.setValueState(sap.ui.core.ValueState.None);
			_control.setValueStateText('');	


		},

		onHdrReviewerChanged: function(oEvent){
			let _user = this.getUser();
			let _val = oEvent.oSource.getValue(),
				_mdl = oEvent.oSource.getModel('mHdr')
				_prq = _prq = _mdl.oData;
			
			let _control = oEvent.oSource;

			let _mKey = _mdl.createKey('/ReviewerSet',{
				Ntid: _val,
				Plant: _pl
			})

			_mdl.read(_mKey,{
				success: function(oData){
					if(!!oData.Ntid){
						_mdl.setProperty('/Inputter',oData.Ntid);
						_mdl.setProperty('/InputterName',oData.Gal);
						// _control.setValue(oData.Gal);	
						_control.setValueState(sap.ui.core.ValueState.None);
						_control.setValueStateText('');	

					} else {
						_mdl.setProperty('/Inputter',_val);
						_mdl.setProperty('/InputterName','');
						// _control.setValue(_val);	
						_control.setValueState(sap.ui.core.ValueState.Error);
						_control.setValueStateText('Invalid Reviewer');	
					}
				},
				error: function(oData){
					_mdl.setProperty('/Inputter',_val);
					_mdl.setProperty('/InputterName','');
					// _control.setValue(_val);	
					_control.setValueState(sap.ui.core.ValueState.Error);
					_control.setValueStateText('Invalid Reviewer');	

				}
			})

		},


		onEkgrpHeadSuggest: function (oEvent) {

			var sTerm = oEvent.getParameter("suggestValue");
			
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("Eknam", FilterOperator.Contains, sTerm));
			}

			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
		},

		onEkgrpHeadChanged: function(oEvent){
			let _oDlgMdl = oEvent.oSource.getModel('mHdr'),
				_self = this,
				_val = oEvent.oSource.getValue(),
				_control = oEvent.oSource,
				_mdl = oEvent.oSource.getModel();


			let _mKey = _mdl.createKey('/PGroupSet',{
				Ekgrp: _val
			})

			_mdl.read(_mKey,{
				success: function(oData){
					if(!!oData.Ekgrp){
						_oDlgMdl.setProperty('/PurchGrp',oData.Ekgrp);
						_control.setValue('('+oData.Ekgrp+') '+oData.Eknam);	
					} else {
						_oDlgMdl.setProperty('/PurchGrp','');
						_control.setValue('');	
					}
				},

				error: function(oData){
					_oDlgMdl.setProperty('/PurchGrp','');
					_control.setValue('');	
				}
			})


		},

		onInvApprHeadSelected: function(oEvent){
			let _oDlgMdl = oEvent.oSource.getModel('mHdr');

			let _mdl = oEvent.oSource.getModel(),
				_val = oEvent.oSource.getValue();

			let sRow = oEvent.getParameter('selectedRow');			
			let sObj = (!!sRow)?sRow.getBindingContext().getObject():null,
			    sKey = (!!sObj)?sObj.NTID:_val;

			let _control = oEvent.oSource;

			if(!sKey) return;

			let _mKey = _mdl.createKey('/EwpSet',{
				NTID: sKey
			})

			_mdl.read(_mKey,{
				success: function(oData){
					if(!!oData.NTID){
						_oDlgMdl.setProperty('/Approver',oData.NTID);
						_oDlgMdl.setProperty('/ApproverName',oData.Gal);
						_oDlgMdl.setProperty('/InvApprTel',oData.PrimaryPhone);
						_oDlgMdl.setProperty('/InvApprEmail',oData.Email);
						_control.setValue(oData.Gal);	
					} else {
						_oDlgMdl.setProperty('/Approver','');
						_oDlgMdl.setProperty('/ApproverName','');
						_oDlgMdl.setProperty('/InvApprEmail', '');
						_oDlgMdl.setProperty('/InvApprTel','');
						_control.setValue('');	
					}
				},
				error: function(oData){
					_oDlgMdl.setProperty('/Approver','');
					_oDlgMdl.setProperty('/ApproverName','');
					_oDlgMdl.setProperty('/InvApprTel','');
					_oDlgMdl.setProperty('/InvApprEmail', '');
					_control.setValue('');	
				}
			})

		},

		onInvApprHeadChanged: function(oEvent){
			let _oDlgMdl = oEvent.oSource.getModel('mHdr');

			let _mdl = oEvent.oSource.getModel(),
				_val = oEvent.oSource.getValue();


			let _control = oEvent.oSource;

			let _mKey = _mdl.createKey('/EwpSet',{
				NTID: _val
			})

			_mdl.read(_mKey,{
				success: function(oData){
					if(!!oData.NTID){
						_oDlgMdl.setProperty('/Approver',oData.NTID);
						_oDlgMdl.setProperty('/ApproverName',oData.Gal);
						_oDlgMdl.setProperty('/InvApprTel',oData.PrimaryPhone);
						_oDlgMdl.setProperty('/InvApprEmail',oData.Email);
						_control.setValue(oData.Gal);	
					} else {
						_oDlgMdl.setProperty('/Approver','');
						_oDlgMdl.setProperty('/ApproverName','');
						_oDlgMdl.setProperty('/InvApprEmail', '');
						_oDlgMdl.setProperty('/InvApprTel','');
						_control.setValue('');	
					}
				},
				error: function(oData){
					_oDlgMdl.setProperty('/Approver','');
					_oDlgMdl.setProperty('/ApproverName','');
					_oDlgMdl.setProperty('/InvApprEmail', '');
					_oDlgMdl.setProperty('/InvApprTel','');
					_control.setValue('');	
				}
			})

		},

		onSelectHdrInvAppr: function (oEvent) {
			let _mdl = oEvent.oSource.getModel(),
				_oDlgMdl = oEvent.oSource.getModel('mHdr');

			sap.ui.core.BusyIndicator.show();
			var _oDlg = new lmco.ces.core.EWPSearch({
				mode: sap.m.ListMode.SingleSelectLeft,
				ewpSet: {
					sPath: '/EwpSet'					
				},
				close: function(oEvent){
					_oDlg.destroy();
					_oDlg = null;
				},
				updated: function(oEvent){
					sap.ui.core.BusyIndicator.hide()
				},
				selected: function(oEvent){
					_oDlg.destroy();

					var aSel = oEvent.getParameter('Item').getObject();
					
					_oDlgMdl.setProperty('/Approver',aSel.NTID);
					_oDlgMdl.setProperty('/ApproverName',aSel.Gal);
					_oDlgMdl.setProperty('/InvApprTel',aSel.PrimaryPhone);
					_oDlgMdl.setProperty('/InvApprEmail',aSel.Email);
		
	
				}
			})
			this.getView().addDependent(_oDlg);
			_oDlg.open();

		},


		onSelectHdrRecipient: function (oEvent) {
			let _mdl = oEvent.oSource.getModel(),
				_oDlgMdl = oEvent.oSource.getModel('mHdr');

			sap.ui.core.BusyIndicator.show();
			var _oDlg = new lmco.ces.core.EWPSearch({
				mode: sap.m.ListMode.SingleSelectLeft,
				ewpSet: {
					sPath: '/EwpSet'					
				},
				close: function(oEvent){
					_oDlg.destroy();
					_oDlg = null;
				},
				updated: function(oEvent){
					sap.ui.core.BusyIndicator.hide()
				},
				selected: function(oEvent){
					_oDlg.destroy();

					var aSel = oEvent.getParameter('Item').getObject();
					
					_oDlgMdl.setProperty('/Recipient',aSel.NTID);
					_oDlgMdl.setProperty('/RecName',aSel.Gal.substr(0,30));
					_oDlgMdl.setProperty('/RecTel',aSel.PrimaryPhone);
					_oDlgMdl.setProperty('/RecEmail',aSel.Email);
		
	
				}
			})
			this.getView().addDependent(_oDlg);
			_oDlg.open();


		},

		onRecHdrValChanged: function(oEvent){
			let _oDlgMdl = oEvent.oSource.getModel('mHdr');

			let _mdl = oEvent.oSource.getModel(),
				_val = oEvent.oSource.getValue();

			let _control = oEvent.oSource;

			let _mKey = _mdl.createKey('/EwpSet',{
				NTID: _val
			})

			_mdl.read(_mKey,{
				success: function(oData){
					if(!!oData.NTID){
						_oDlgMdl.setProperty('/Recipient',oData.NTID);
						_oDlgMdl.setProperty('/RecName',oData.Gal.substr(0,30));
						_oDlgMdl.setProperty('/RecTel',oData.PrimaryPhone);
						_oDlgMdl.setProperty('/RecEmail',oData.Email);
						_control.setValue(oData.Gal);	
					} else {
						_oDlgMdl.setProperty('/RecName','');
						_oDlgMdl.setProperty('/RecTel','');
						_oDlgMdll.setProperty('/RecEmail', '');
						_oDlgMdl.setProperty('/Recipient','');
						_control.setValue('');	
					}
				},
				error: function(oData){
					_oDlgMdl.setProperty('/RecName','');
					_oDlgMdl.setProperty('/RecTel','');
					_oDlgMdl.setProperty('/RecEmail', '');
					_oDlgMdl.setProperty('/Recipient','');
					_control.setValue('');	
				}
			})

		},

		onRecipientHdrSelected: function(oEvent){
			let _oDlgMdl = oEvent.oSource.getModel('mHdr');

			let _mdl = oEvent.oSource.getModel(),
				_val = oEvent.oSource.getValue();

			let sRow = oEvent.getParameter('selectedRow');			
			let sObj = (!!sRow)?sRow.getBindingContext().getObject():null,
			    sKey = (!!sObj)?sObj.NTID:_val;

			let _control = oEvent.oSource;


			if(!sKey) return;

			let _mKey = _mdl.createKey('/EwpSet',{
				NTID: sKey
			})

			_mdl.read(_mKey,{
				success: function(oData){
					if(!!oData.NTID){
						_oDlgMdl.setProperty('/Recipient',oData.NTID);
						_oDlgMdl.setProperty('/RecName',oData.Gal.substr(0,30));
						_oDlgMdl.setProperty('/RecTel',oData.PrimaryPhone);
						_oDlgMdl.setProperty('/RecEmail',oData.Email);
						_control.setValue(oData.Gal);	
					} else {
						_oDlgMdl.setProperty('/RecName','');
						_oDlgMdl.setProperty('/RecTel','');
						_oDlgMdll.setProperty('/RecEmail', '');
						_oDlgMdl.setProperty('/Recipient','');
						_control.setValue('');	
					}
				},
				error: function(oData){
					_oDlgMdl.setProperty('/RecName','');
					_oDlgMdl.setProperty('/RecTel','');
					_oDlgMdl.setProperty('/RecEmail', '');
					_oDlgMdl.setProperty('/Recipient','');
					_control.setValue('');	
				}
			})

		},

		handleHdrDateChange(oEvent){

			let _mdl = oEvent.oSource.getModel('mHdr');


			let _from = new Date(oEvent.getParameter('from')).YYYYMMDD(),
				_to = new Date(oEvent.getParameter('to')).YYYYMMDD();

			_mdl.setProperty('/PipStart',_from);
			_mdl.setProperty('/PipEnd',_to);

			// _mdl.refresh(true);

		},


		getCompliance: function(oData){

		},

		onConfirmCreateNewRequest: function(oEvent){

			let _data = oEvent.oSource.getModel('mHdr').oData,
				_mdl = oEvent.oSource.getModel('mHdr');

			let _pLoad = {};

			this._validateNewRequest(_mdl)
			.done(function(oRes){
				Object.keys(_data).forEach((_k) => { 
					_pLoad[_k] = (_data[_k] instanceof Date)? _data[_k].YYYYMMDD() :_data[_k];
				})
	
				controller.getOwnerComponent()._oErrorHandler._bMessageOpen = true;
	
				controller.getModel().create('/HeaderSet', _pLoad, {
					success: function(oData){
						if(controller._newDlg){
							controller._newDlg.close();
							controller._newDlg.destroy();				
							controller._newDlg = null;
						}
			
						controller.getRouter().navTo("object", {
							objectId: oData.PrqNo,
							query: {
								tab: "itemList"
							}
						}, true);
		
						// controller.getModel().refresh(true);
					},
					error: function(oError, oResponse){
						let _msg = JSON.parse(oError.responseText);
						sap.m.MessageBox.error(_msg.error.message.value);
	
					}
	
				})
	
			})
			.fail(function(){
				// no action
			})


		},

		_validateNewRequest: function(oModel) {
			let _promise = $.Deferred();

			let _self = this;
			let _dt = oModel.oData;

			let _revValid = (!!_dt.bSetReviewer)?(!!_dt.Inputter):true;

			

			if(_dt.eSigAccept && _dt.PreqName && _dt.PreqText && _dt.Plant && _dt.RecName && _dt.ChargeNum && !!_revValid) {
				return _promise.resolve(true);
			} else {

				sap.m.MessageBox.error("Please fill out all required fields", {
					onClose: function (sAction) {
						return _promise.reject(false);
					},
				});						

				
				// let _eSigDlg = new sap.m.Dialog({					
				// 	title: "Compliance Acknowledgement",
				// 	content: [
				// 		new sap.m.FormattedText({
				// 			htmlText: this.getResourceBundle().getText("TxtAckFull"),
				// 			class: 'sapUiSmallMargin'
				// 		}),
				// 		new sap.m.CheckBox({
				// 			text: 'I acknowledge compliance for this form',
				// 			selected: "{eSig>/eSigAccept}"
				// 		})
				// 	],
				// 	beginButton: new sap.m.Button({
				// 		type: sap.m.ButtonType.Emphasized,
				// 		id:'__eSigSubmit',
				// 		text: "Submit",
				// 		enabled: {
				// 			path: "eSig>/eSigAccept",
				// 			formatter: function(a){
				// 				return(!!a)?true:false;
				// 			}
				// 		},
				// 		press: function () {
				// 			_promise.resolve(true);
				// 			_eSigDlg.close();
				// 			_eSigDlg.destroy();				
				// 			_eSigDlg = null;
				// 		}.bind(this)
				// 	}),
				// 	endButton: new sap.m.Button({
				// 		text: "Cancel",
				// 		press: function () {
				// 			_eSigDlg.close();
				// 			_eSigDlg.destroy();				
				// 			_eSigDlg = null;
				// 			_promise.reject();
				// 		}.bind(this)
				// 	})
				// });
	
				// _eSigDlg.setModel(oModel, 'eSig');
				// _eSigDlg.open();
	
				return _promise;
	
			}

		},


		onCreateOptionsChange: function(oEvent){
			let _mdl = oEvent.oSource.getModel('mHdr'),
				_data = _mdl.getProperty('/');

			if(!_data.bMaterial) {
				// _mdl.setProperty('/bOverLimit',false);
				_mdl.setProperty('/bDeliverable',false);
				_mdl.setProperty('/bLMuse',false);
			}

			// if(!_data.bOverLimit) {
			// 	_mdl.setProperty('/bDeliverable',false);
			// 	_mdl.setProperty('/bLMuse',false);
			// }

			if(!_data.bDeliverable) {
				_mdl.setProperty('/bLMuse',false);
			}


		},

		handleCancelNewRequest: function(oEvent){
			if(controller._newDlg){
				controller._newDlg.close();
				controller._newDlg.destroy();				
				controller._newDlg = null;
			}
		},
		
		onOpenViewSettings : function (oEvent) {
			var sDialogTab = "filter";
			if (oEvent.getSource().isA("sap.m.Button")) {
				var sButtonId = oEvent.getSource().getId();
				if (sButtonId.match("sort")) {
					sDialogTab = "sort";
				} else if (sButtonId.match("group")) {
					sDialogTab = "group";
				}
			}
			// load asynchronous XML fragment
			if (!this._pViewSettingsDialog) {
				this._pViewSettingsDialog = Fragment.load({
					id: this.getView().getId(),
					name: "lmco.ces.preq.view.ViewSettingsDialog",
					controller: this
				}).then(function(oDialog){
					// connect dialog to the root view of this component (models, lifecycle)
					this.getView().addDependent(oDialog);
					oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
					return oDialog;
				}.bind(this));
			}
			this._pViewSettingsDialog.then(function(oDialog) {
				oDialog.open(sDialogTab);
			});
		},

		/**
		 * Event handler called when ViewSettingsDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters or groupers
		 * are applied to the master list, which can also mean that they
		 * are removed from the master list, in case they are
		 * removed in the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @public
		 */
		onConfirmViewSettingsDialog : function (oEvent) {
			var aFilterItems = oEvent.getParameter("filterItems"),
				aFilters = [],
				aCaptions = [];
			aFilterItems.forEach(function (oItem) {
				switch (oItem.getKey()) {
					case "New":
						aFilters.push(new Filter("Status", FilterOperator.EQ, '002'));
						break;
					case "Reject":
						aFilters.push(new Filter("Status", FilterOperator.EQ, '004'));
						break;
					case "Review":
						aFilters.push(new Filter("Status", FilterOperator.BT, '008','016'));
						break;
					default:
					break;
				}
				aCaptions.push(oItem.getText());
			});
			this._oListFilterState.aFilter = aFilters;
			this._updateFilterBar(aCaptions.join(", "));
			this._applyFilterSearch();
			// this._applySorter(oEvent);
			this._applyGrouper(oEvent);
		},

		/**
		 * Apply the chosen grouper to the master list
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @private
		 */
		_applyGrouper: function (oEvent) {
			var mParams = oEvent.getParameters(),
				sPath,
				bDescending,
				aSorters = [];
			// apply sorter to binding
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				var vGroup = this._oGroupFunctions[mParams.groupItem.getKey()];
				aSorters.push(new Sorter(sPath, bDescending, vGroup));
			}
			if (mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending,false));
			}
			this._oList.getBinding("items").sort(aSorters);
		},

		_applySorter: function (oEvent) {
			var mParams = oEvent.getParameters(),
				sPath,
				bDescending,
				aSorters = [];
			// apply sorter to binding
			if (mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending,false));
			}
			this._oList.getBinding("items").sort(aSorters);
		},


		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange : function (oEvent) {
			var oList = oEvent.getSource(),
				oMdl = this.getModel(),
				_app = this.getModel("appView"),
				_editMode = _app.getProperty("/editMode"),
				_self = this,
				_selItem = oEvent.getParameter('listItem'),
				_currentItem = _app.getProperty("/selectedReq"),
				bSelected = oEvent.getParameter("selected");

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				if(oMdl.hasPendingChanges()){
					sap.m.MessageBox.warning("There are unsaved changes that will be lost if you switch to another request. Continue?", {
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						emphasizedAction: sap.m.MessageBox.Action.OK,
						onClose: function (sAction) {
							if(sAction===sap.m.MessageBox.Action.YES) {
								// this.closeMultiSelection();
								oMdl.resetChanges();
								_app.setProperty("/editMode", false);
								_app.refresh(true);		
								_app.setProperty("/selectedReq", _selItem)
								_self._showDetail(_selItem );
							} else {
								oList.setSelectedItem(_currentItem);
							}
						},
						dependentOn: this.getView()
					});						
		
				} else {
					_app.setProperty("/editMode", false);
					_app.refresh(true);	
					_app.setProperty("/selectedReq", _selItem)
					this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
				}
				// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				
			}
		},

		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed : function () {
			this._oList.removeSelections(true);
		},

		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		createGroupHeader : function (oGroup) {
			return new GroupHeaderListItem({
				title : oGroup.text,
				upperCase : false
			});
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */
		delAddress: function (sHouseNo, sStreet, sCity, sState, sPstlz) {
			return(sHouseNo+' '+sStreet + ', '+ sCity + ', '+sState+', '+sPstlz);
		},


		_createViewModel : function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "Filter Bar",
				delay: 0,
				selectedTab: "",
				titleCount: 0,
				noDataText: this.getResourceBundle().getText("masterListNoDataText")
			});
		},

		_createFilterModel : function() {
			return new JSONModel({
				reviewer: null,
			});
		},


		_onMasterMatched :  function() {
			//Set the layout property of the FCL control to 'OneColumn'
			let _viewModel = this.getView().getModel("masterView"),
				_tab = _viewModel.getProperty("/selectedTab");


			if(!_tab) {
				_viewModel.setProperty("/selectedTab","mylist");
			} else {
				switch(_tab){
					case 'mylist': this.displayMyList(); break;
					case 'review': this.displayApprovals(); break;
					case 'submitted': this.displaySubmitted(); break;
					case 'approved': this.displayApproved(); break;
					case 'history': this.displayHistory(); break;
				}	
			}


			this.getModel("appView").setProperty("/layout", "OneColumn");
		},

		onMasterTabSelect: function(oEvent){
			let _tab = oEvent.getParameter('key');

			this.getModel("appView").setProperty("/layout", "OneColumn");
			
			switch(_tab){
				case 'mylist': this.displayMyList(); break;
				case 'review': this.displayApprovals(); break;
				case 'submitted': this.displaySubmitted(); break;
				case 'approved': this.displayApproved(); break;
				case 'history': this.displayHistory(); break;
			}

		},

		displayMyList: function(){
			let _bi = this._oList.getBindingInfo('items'),
				_tpl = _bi.template,
				_path = (_bi)?_bi.path:'',
				_bnd = (_bi)?_bi.binding:null,
				aSorters = (_bnd)?_bnd.aSorters:[new sap.ui.model.Sorter(_path)];

				let aFilters = [
					new Filter('CName', 'EQ', this.getUser().getId())
				]
				this.getModel("appView").setProperty("/opmode", "");
				this._oList.bindAggregation("items", {
					path: "/HeaderSet",
					template: _tpl,
					filters: aFilters,
					sorters: aSorters
				});	
		},

		displayApprovals: function(){
			let _bi = this._oList.getBindingInfo('items'),
				_tpl = _bi.template,
				_path = (_bi)?_bi.path:'',
				_bnd = (_bi)?_bi.binding:null,
				aSorters = (_bnd)?_bnd.aSorters:[new sap.ui.model.Sorter(_path)];

				let aFilters = [
					new Filter('CName', 'EQ', this.getUser().getId()),
					new Filter('Opmode', 'EQ', 'A')
				]

				this.getModel("appView").setProperty("/opmode", "A");

				this.byId('__preqList').bindAggregation("items", {
					path: "/HeaderSet",
					template: _tpl,
					filters: aFilters,
					sorters: aSorters
				});	
		},

		displaySubmitted: function(){
			let _bi = this._oList.getBindingInfo('items'),
				_tpl = _bi.template,
				_flt = this.getModel('flt'),
				_inputter = _flt.getProperty('/inputter'),
				_path = (_bi)?_bi.path:'',
				_bnd = (_bi)?_bi.binding:null,
				aSorters = (_bnd)?_bnd.aSorters:[new sap.ui.model.Sorter(_path)];

				this.getModel("appView").setProperty("/opmode", "S");

				let aFilters = [
					new Filter('CName', 'EQ', this.getUser().getId()),
					new Filter('Opmode', 'EQ', 'S')
				]

				if(!!_inputter) aFilters.push(new Filter('Inputter', 'EQ', _inputter))
	
				this.byId('__preqList').bindAggregation("items", {
					path: "/HeaderSet",
					template: _tpl,
					filters: aFilters,
					sorters: aSorters
				});	
		},

		displayHistory: function(){
			let _bi = this._oList.getBindingInfo('items'),
				_tpl = _bi.template,
				_path = (_bi)?_bi.path:'',
				_bnd = (_bi)?_bi.binding:null,
				_appMode = this.getModel("appView").getProperty('/approveMode'),
				aSorters = (_bnd)?_bnd.aSorters:[new sap.ui.model.Sorter(_path)],
				_opMode = (_appMode)?'Z':'H';

				this.getModel("appView").setProperty("/opmode", _opMode);

				let aFilters = [
					new Filter('CName', 'EQ', this.getUser().getId()),
					new Filter('Opmode', 'EQ', _opMode)
				]
	
				this.byId('__preqList').bindAggregation("items", {
					path: "/HeaderSet",
					template: _tpl,
					filters: aFilters,
					sorters: aSorters
				});	
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail : function (oItem) {
			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getModel("appView").setProperty("/reqView", true);

			this.getRouter().navTo("object", {
				objectId : oItem.getBindingContext().getProperty("PrqNo")
			}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {int} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount : function (iTotalItems) {
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				this.getModel("masterView").setProperty("/titleCount", iTotalItems);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch : function () {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar : function (sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		}

	});
});