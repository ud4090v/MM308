sap.ui.define([
	"sap/ui/model/type/Currency",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Currency, Filter, FilterOperator) {
	"use strict";

	return {

		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {number} iQuantity product quantity
		 * @param {number} fPrice product price
		 * @param {string} sCurrencyCode currency code for the price
		 * @returns {string} formatted currency value with 2 digits
		 */
		calculateItemTotal: function (iQuantity, fPrice) {
			var oCurrency = new Currency({showMeasure: false});
			var fTotal = iQuantity * fPrice;
			return oCurrency.formatValue([fTotal.toFixed(2), 'USD'], "string");
		},

		/**
		 * Converts a binary string into an image format suitable for the src attribute
		 *
		 * @public
		 * @param {string} vData a binary string representing the image data
		 * @returns {string} formatted string with image metadata based on the input or a default image when the input is empty
		 */
		handleBinaryContent: function(vData){
			if (vData) {
				var sMetaData1 = 'data:image/jpeg;base64,';
				var sMetaData2 = vData.substr(104); // stripping the first 104 bytes from the binary data when using base64 encoding.
				return sMetaData1 + sMetaData2;
			} else {
				return "../images/Employee.png";
			}
		},

		/**
		 * Provides a text to indicate the delivery status based on shipped and required dates
		 *
		 * @public
		 * @param {object} oRequiredDate required date of the order
		 * @param {object} oShippedDate shipped date of the order
		 * @returns {string} delivery status text from the resource bundle
		 */
		deliveryText: function (oRequiredDate, oShippedDate) {
			var oResourceBundle = this.getModel("i18n").getResourceBundle();

			if (oShippedDate === null) {
				return "None";
			}

			// delivery is urgent (takes more than 7 days)
			if (oRequiredDate - oShippedDate > 0 && oRequiredDate - oShippedDate <= 432000000) {
				return oResourceBundle.getText("formatterDeliveryUrgent");
			} else if (oRequiredDate < oShippedDate) { //d elivery is too late
				return oResourceBundle.getText("formatterDeliveryTooLate");
			} else { // delivery is in time
				return oResourceBundle.getText("formatterDeliveryInTime");
			}
		},

		formatCCApproval: function(bApprove, aStatus, sName, sDate, sTime){
			if(!!bApprove){
				if(!aStatus){
					if(!!sName) {
						return 'Awaiting CC Approval';
					} else {
						return 'Pending';
					}
				} else if(aStatus==='-'){
					if(!!sName) {
						return 'Rejected on ' + sDate + ' at ' + sTime;
					} else {
						return 'Rejected';
					}
					
				} else if(aStatus==='X') {
					if(!!sName) {
						return 'Approved on ' + sDate + ' at ' + sTime;
					} else {
						return 'Approved';
					}
				}	
			} else {
				return '';
			}
		},

		formatCCStatusIcon: function(bApprove, aStatus, sName, sDate, sTime){
			if(!!bApprove){
				if(!aStatus){
					if(!sName){
						return 'sap-icon://message-warning';
					} else {
						return 'sap-icon://employee-approvals';
					}
					
				} else if(aStatus==='-'){
					return 'sap-icon://decline';
				} else if(aStatus==='X') {
					return 'sap-icon://accept';
				}	
			} else {
				return 'sap-icon://accept';
			}
		},

		formatCCStatusIconTooltip: function(bApprove, aStatus, sName, sDate, sTime){
			if(!!bApprove){
				if(!aStatus){
					if(!sName){
						return 'The Cost Center assignment must be approved by the CC Manager';
					} else {
						return 'The Cost Center assignment is under review';
					}
					
				} else if(aStatus==='-'){
					return 'The Cost Center assignment was rejected by the CC Manager';
				} else if(aStatus==='X') {
					return 'The Cost Center assignment was approved';
				}	
			} else {
				return 'No Approval is required';
			}
		},

		formatCCStatusIconColor: function(bApprove, aStatus, sName, sDate, sTime){
			if(!!bApprove){
				if(!aStatus){
					if(!sName){
						return 'Tile';
					} else {
						return 'Critical';
					}										
				} else if(aStatus==='-'){
					return 'Negative';
				} else if(aStatus==='X') {
					return 'Positive';
				}	
			} else {
				return 'Neutral';
			}
		},

		formatCCStatusIconColorClass: function(aStatus, sName, sDate, sTime){
			if(!!bApprove){
				if(!aStatus){
					if(!sName){
						return 'prq-status-neutral';
					} else {
						return 'prq-status-pending';
					}					
				} else if(aStatus==='-'){
					return 'prq-status-negative';
				} else if(aStatus==='X') {
					return 'prq-status-positive';
				}	
			} else {
				return 'prq-status-neutral';
			}
		},

		// Post Icon
		formatPostStatusIcon: function(bApprove, aStatus){
			return (!!aStatus)?'sap-icon://accept':'sap-icon://decline';
		},

		formatPostNotes: function(aStatus, sNotes){
			if(!!aStatus){
				return 'Approved for posting in P2P';
			} else {
				return (!!sNotes)?sNotes:'Rejected for posting to P2P';
			}	
		},

		formatPostStatusIconColor: function(bApprove, aStatus){
			return (!!aStatus)?'Positive':'Negative';
		},

		formatPostStatusIconColorClass: function(aStatus, sName, sDate, sTime){
			return (!!aStatus)?'prq-status-positive':'prq-status-negative';
		},


		/**
		 * Provides a semantic state to indicate the delivery status based on shipped and required dates
		 *
		 * @public
		 * @param {object} oRequiredDate required date of the order
		 * @param {object} oShippedDate shipped date of the order
		 * @returns {string} semantic state of the order
		 */
		deliveryState: function (oRequiredDate, oShippedDate) {
			if (oShippedDate === null) {
				return "None";
			}

			// delivery is urgent (takes more than 7 days)
			if (oRequiredDate - oShippedDate > 0 && oRequiredDate - oShippedDate <= 432000000) {
				return "Warning";
			} else if (oRequiredDate < oShippedDate) { // delivery is too late
				return "Error";
			} else { // delivery is in time
				return "Success";
			}
		},
		urgencyState: function (oUrgency) {
			if (oUrgency === null) {
				return "None";
			}
			return "None";

			// delivery is urgent (takes more than 7 days)
		},
		urgencyText: function (oUrgency, oDCMA, oPlant) {
			var oResourceBundle = this.getModel("i18n").getResourceBundle();

			if(oDCMA) return 'DCMA Certified';
			return 'Normal';

		},
		SubmitBtnTitle: function(bEditable,bReview, bCCApprove,sMode){
			if(sMode==='A' || sMode==='S') { 
				return(!!bReview)?'Review':'Submit';
			} else if(sMode==='') {
				if(bCCApprove){
					return 'Email CC Approver';
				} else {
					return 'Submit';
				}
			} else {
				return '';	
			}
			
		},
		SuccessFailed:  function(bValue){
			return(bValue?'Success':'Failed');
		},
		CharSuccessFailed:  function(bValue){
			switch(bValue) {
				case 'X': return 'Success'; 
				case '-': return 'Failed';
				default: return '';
			}
		},
		postBtnVisible: function(sMode, bApprove){
			let _app = this.getModel('appView').oData;
			if(sMode==='A' && !!bApprove && !_app.editMode) {
				return true;
			} else {
				return false;
			}
		},
		userBtnVisible: function(sMode, bFlag, bEdit){
			let _app = this.getModel('appView').oData;
			if(sMode==='' && !!bFlag && !bEdit && !_app.editMode) {
				return true;
			} else {
				return false;
			}
		},

		showBanfn: function(sNum,sStat){
			return(!!sNum)?true:false;
		},
		
		SubmitBtnVisible: function(bEdit,bEditable,bReview,bApprove,sMode){
			if(sMode==='S'){
				// return false;
				if(!bEdit && (!!bEditable || !!bReview )) {
					return true;
				} else {
					return false;
				}	
			} else if(sMode==='A'){
				// return false;
				if(!!bReview ) {
					return true;
				} else {
					return false;
				}	
			} else if(sMode===''){
				if(!!bEditable && !bEdit && !bReview && !bApprove) {
					return true;
				} else {
					return false;
				}	
			} else {
				return false;
			}
		},

		ReviewBtnVisible: function(bEdit,bEditable,bReview, sMode){
			if(sMode==='A' || sMode==='S'){
				if(!bEdit && !!bReview) {
					return true;
				} else {
					return false;
				}	
			} else if(sMode===''){
				return false;
			}
		},

		formatAttachURL: function(prrnr,seqnr,cnt){
			let _user = this.getUser();
			return this.getModel().sServiceUrl+this.getModel().createKey('/AttachmentSet',{Prrnr:prrnr,Seqnr:seqnr,Cname: _user.getId(), Cnt:cnt})+'/$value';
		},
		formatMimetypeIcon: function(mimetype){
			return sap.ui.core.IconPool.getIconForMimeType(mimetype);
		},
		StatusColor: function(status){
			switch(status){
				case '002': return 6;
				case '004': return 3;
				case '008': return 7;
				case '016': return 2;
				case '032': return 8;
				case '064': return 5;
				case '512': return 9;
				default: return 0;
			}
		},
		NewReqBtnVisible: function(sMode){
			if(sMode===''){
				return true;
			} else {
				return false;
			}
		},

		StatusState: function(status){
			switch(status){
				case '002': return 'Indication05';	//	New - Blue - Emphasized
				case '004': return 'Error'; 		//	Rejected - Red - Negative
				case '008': return 'Indication06'; 	//	Submitted - Teal
				case '016': return 'Indication03'; 	//	Review - Orange - Critical
				case '032': return 'Success';		// 	Success - Green - Success
				case '064': return 'None';
				case '512': return 'None';
				default: return 'None';
			}
		},

		MenuBtnType: function(status){
			switch(status){
				case '002': return 'Neutral';	//	New - Blue - Emphasized
				case '004': return 'Negative'; 		//	Rejected - Red - Negative
				case '008': return 'Emphasized'; 	//	Submitted - Teal
				case '016': return 'Critical'; 	//	Review - Orange - Critical
				case '032': return 'Success';		// 	Success - Green - Success
				case '064': return 'Neutral';
				case '512': return 'Neutral';
				default: return 'Neutral';
			}
		},

		MenuBtnIcon: function(status){
			switch(status){
				case '002': return 'sap-icon://create';	//	New - Blue - Emphasized
				case '004': return ''; 		//	use default icon
				case '008': return 'sap-icon://to-be-reviewed'; 	//	Submitted - Teal
				case '016': return 'sap-icon://in-progress'; 	//	Review - Orange - Critical
				case '032': return '';		// 	Success - use default
				case '064': return 'sap-icon://status-completed';
				case '512': return 'sap-icon://history';
				default: return '';
			}
		},


		delAddress: function (sHouseNo, sStreet, sCity, sState, sPstlz) {
			return(sHouseNo+' '+sStreet + ', '+ sCity + ', '+sState+', '+sPstlz);
		},
		boolYesNo: function(bValue){
			return(bValue)?'Yes':'No';
		},

		createdStamp: function (cDat, cName) {
			let _df = new Intl.NumberFormat(),
				_fd,
				_l = _df.resolvedOptions().locale;

			try {
				_fd = new Date(cDat).toLocaleDateString(_l,{ dateStyle: 'medium' })
			}			
			catch(x) {
				_fd = '';
			}

			return _fd+', by '+cName;

		},
		str2date: function(sDate){
			let _dt;
			
			if(!sDate) {
				return new Date();
			} else {
				if(sDate.includes('/')){
					_dt = new Date(sDate);				
					if(_dt instanceof Date && !isNaN(_dt)) {
						return _dt;
					} else {
						return new Date();
					}
	
				} else {
					let _yy=sDate.substring(1,4),
						_mm=sDate.substring(4,6),
						_dd=sDate.substring(6,8);
					_dt = new Date(_mm+'/'+_dd+'/'+_yy);
					if(_dt instanceof Date && !isNaN(_dt)) {
						return _dt;
					} else {
						return new Date();
					}
	
				}
	
			}


		},

		yyyymmdd2date: function(sDate){
			let _yy=sDate.substring(1,4),
				_mm=sDate.substring(4,6),
				_dd=sDate.substring(6,8);
			return new Date(_mm+'/'+_dd+'/'+_yy);
		},

		p2pStatus: function(bForeign, bHazmat, bMaterial, bOverLimit, bDeliverable, bLMuse){
			if(!!bForeign || !!bHazmat) return 'Not Compliant';
			if(!!bMaterial){
				// if(!!bOverLimit){
					// if(!!bDeliverable){
					// 	if(!!bLMuse) {
					// 		return 'Compliant';
					// 	} else {
					// 		return 'Not Compliant';
					// 	}
					// } else {
						// return 'Compliant';
					// }
				// } else {
				// 	return 'Compliant';
				// }
				return 'Compliant';
			} else {
				return 'Compliant';
			}
		},

		p2pState: function(bForeign, bHazmat, bMaterial, bOverLimit, bDeliverable, bLMuse){
			if(!!bForeign || !!bHazmat) return 'Error';
			if(!!bMaterial){
				// if(!!bOverLimit){
				// 	if(!!bDeliverable){
				// 		if(!!bLMuse) {
				// 			return 'Success';
				// 		} else {
				// 			return 'Error';
				// 		}
				// 	} else {
				// 		return 'Success';
				// 	}
				// } else {
				// 	return 'Success';
				// }
				return 'Success';
			} else {
				return 'Success';
			}
		},


		p2pOK: function(bForeign, bHazmat, bMaterial, bOverLimit, bDeliverable, bLMuse){
			if(!!bForeign || !!bHazmat) return false;
			if(!!bMaterial){
				// if(!!bOverLimit){
				// 	if(!!bDeliverable){
				// 		if(!!bLMuse) {
				// 			return true;
				// 		} else {
				// 			return false;
				// 		}
				// 	} else {
				// 		return true;
				// 	}
				// } else {
				// 	return true;
				// }
				return true;
			} else {
				return true;
			}
		},

		p2pAckOK: function(bAcknowledge){
			// if(!!bForeign || !!bHazmat) return false;
			if(!!bAcknowledge){
				return true;
			} else {
				return false;
			}
		},

		p2pAckNotOK: function(bForeign, bHazmat, bMaterial, bOverLimit, bDeliverable, bLMuse, bAcknowledge){
			if(!!bForeign || !!bHazmat) return false;
			if(!!bAcknowledge){
				return false;
			} else {
				return true;
			}
		},

		p2pText: function(bForeign, bHazmat, bMaterial, bOverLimit, bDeliverable, bLMuse){
			if(!!bForeign) return '<p><strong>STOP and do not proceed with this form!</strong><br>When procuring material / services from a Foreign vendor, please contact your site ITC office for export/import compliance guidance.</p>'
			if(!!bHazmat) return '<p><strong>STOP and do not proceed with this form!</strong><br>When procuring hazardous material, please contact your site ITC office for compliance guidance.</p>';
			// return this.getResourceBundle().getText("TxtCompiance");
			return this.getResourceBundle().getText("TxtCompianceFull");
		},
		p2pNotCompl: function(bForeign, bHazmat, bMaterial, bOverLimit, bDeliverable, bLMuse){
			if(!!bForeign) return ''
			if(!!bHazmat) return '';
			return this.getResourceBundle().getText("TxtNotCompiance");
		},
		p2pAcknowledge: function(bForeign, bHazmat, bMaterial, bOverLimit, bDeliverable, bLMuse){
			if(!!bForeign) return ''
			if(!!bHazmat) return '';
			return this.getResourceBundle().getText("TxtAcknowledgeComp");
			// return this.getResourceBundle().getText("TxtCompianceFull");
		},

		getProductText: function(a,b,c){

		}, 
		headerMatEdit: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && !_app.approveMode && !c && !!d ;
		},

		headerEmatEdit: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && !_app.approveMode && !!c  ;
		},

		itemMatEdit: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !!_app.itemView && !_app.approveMode && !c && !!d ;
		},

		itemMatVisible: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !_app.approveMode && !c && !!d ;
		},

		itemEmatVisible: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !_app.approveMode && !!c ;
		},

		itemEmatEdit: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !!_app.itemView && !_app.approveMode && !!c ;
		},


		headerEdit: function(a,b){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && !_app.approveMode;
		},

		headerAllEdit: function(a,b){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView;
		},
		headerApproverEdit: function(a,b){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && !!_app.approveMode && !!_app.bInputter;
		},
		headerMatPropEdit: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && !_app.approveMode && !!c && !!d;
		},
		headerMatklEdit: function(a,b,c,d){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && !_app.approveMode && ( !!c || !d );
		},
		UOMEdit: function(a,b,c){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && c && !_app.approveMode;
		},
		UOMItemEdit: function(a,b,c){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !!_app.itemView && c;
		},
		getMatnr: function(d){
			return d;
		},
		formatbSingle: function(a,bSplit) {
			return (!!a && !bSplit);
		},
		notSplit: function(bSplit) {
			return (!bSplit);
		},
		itemDelete: function(a,b,c){
			let _app = this.getModel('appView').oData;
			let _view = this.getModel('detailView').oData;
			return !!_app.editMode && !_app.itemView && (_view.selMode==='None');
		},
		headerSaveBtn: function(a,b){
			let _app = this.getModel('appView').oData;
			// return !!_app.editMode && !_app.itemView && this.getModel().hasPendingChanges();
			return !!_app.editMode && !_app.itemView;
		},
		itemSaveBtn: function(a,b){
			let _app = this.getModel('appView').oData;
			// return !!_app.editMode && !!_app.itemView && this.getModel().hasPendingChanges();
			return !!_app.editMode && !!_app.itemView;
		},
		attListMode: function(a,b){
			let _app = this.getModel('appView').oData;
			return (!!_app.editMode && !_app.itemView)?"Delete":"None";
		},
		headerMaterialEdit: function(a,b,c){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !_app.itemView && c==='M';
		},
		isMaterial: function(c){
			return c==='M';
		},
		itemEdit: function(a,b){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !!_app.itemView && !_app.approveMode;
		},
		itemApproverEdit: function(a,b){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !!_app.itemView && !!_app.approveMode;
		},
		itemAllEdit: function(a,b){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !!_app.itemView;
		},
		itemHazmatEdit: function(a,b,c){
			let _app = this.getModel('appView').oData;
			return !!_app.editMode && !!_app.itemView && !!c;
		},
		minDlvDate: function(a){
			let _dt;
			if(!!a){
				_dt = new Date(a);
				if(_dt instanceof Date){
					return _dt;
				} else {
					return new Date();
				}
			} else {
				return new Date();
			}
		},

		getMatnrValueState: function(sMatnr, sMaktx, bNew){
			if(!sMatnr){
				if(!!sMaktx) {
					return(!bNew)?'Error':'None';
				} else {
					return 'None';
				}
			} else {
				return 'None';
			}
		},

		formatMsgUrl: function(sUrl){
			if(!sUrl){
				return null;
			}
			else {
				return new sap.m.Link({
					text: "Show more information",
					href:  sUrl,
					target: "_blank"
				})

			}
		},

		
		getXXValueState: function(sKey, sText){
			if(!sKey){
				if(!!sText) {
					return 'Error';
				} else {
					return 'None';
				}
			} else {
				return 'None';
			}
		},

		getXXValueStateText: function(sKey, sText){
			if(!sKey){
				if(!!sText) {
					return 'Invalid Value. Use Suggestion help to select';
				} else {
					return '';
				}
			} else {
				return '';
			}
		},

		formatDateYYMMDD: function(d){

		},


		getMatnrStateText: function(sMatnr, sMaktx, bNew){
			if(!sMatnr){
				if(!!sMaktx) {
					return(!bNew)?'If you are entering a new product that does not exist in LM system yet, select "Short Text Only"':'';
				} else {
					return '';
				}
			} else {
				return '';
			}
		},

		formatMaterial: function(sMatnr, sMaktx, bNew){
			if(!sMatnr){
				if(!!sMaktx) {
					return sMaktx;
				} else {
					return '';
				}
			} else {
				if(bNew){
					return sMatnr;
				} else {
					return '('+sMatnr+') '+sMaktx;
				}
			}
		},

		formatMaterialGroup: function(sMatnr, sMaktx){
			return '('+sMatnr+') '+sMaktx;
		},

		highlightStatus: function(status){
			switch(status){
				case 'E': return 'Error';
				case 'I': return 'Information';
				case 'W': return 'Warning';
				case 'S': return 'Success';
				case 'N': return 'None';
				default: return 'None'
			}
		},

		ReqIcon: function(bRep){
			return (bRep)?"sap-icon://wrench":"";
		},


		buildMatnrFilter: function(sMatnr){
			return new Filter("Matnr", FilterOperator.EQ, sMatnr)
		},
		formatEkgrp: function(sKey, sText){
			if(!sKey){
				if(!!sText) {
					return sText;
				} else {
					return '';
				}
			} else {
				if(!sText){
					return sKey;
				} else {
					return '('+sKey+') '+sText;
				}
			}
		},

		formatInputter: function(sKey, sText){
			if(!sKey){
				if(!!sText) {
					return sText;
				} else {
					return '';
				}
			} else {
				if(!sText){
					return sKey;
				} else {
					return '('+sKey+') '+sText;
				}
			}
		},


		str2DEC: function(sValue){

		},
		formatXX: function(sKey, sText){
			if(!sKey){
				if(!!sText) {
					return sText;
				} else {
					return '';
				}
			} else {
				return '('+sKey+') '+sText;
			}
		},
		hasPendingChanges(d){
			return this.getModel().hasPendingChanges();
		},
		formatTitle: function(s1, s2, s3){
			// return s1 + '('+s2+')';
			return (s3)?'Repair Request #'+s2:'Request #'+s2;
		},

		formatIntro: function(s1, s2, s3, s4){
			// return s1 + '('+s2+')';
			return (s4)?'Repair:'+s2:s2;
		},


		formatItemTitle: function(s0, s1, s2){
			return 'Item #'+s0+' : '+s2+ ' ('+s1+')';
		},
		calcTotal: function(p,q){
			return p * q;
		},
		calcTotalCost: function(p,q, c){
			let _c = p * q;
			return _c.toFixed(2)+' '+c;
			// return _c.toFixed(2);
		},
		formatDec2Number: function(c){
			// let formattedNumber = new Intl.NumberFormat('en-US', {
			// 	minimumFractionDigits: 2,
			// 	maximumFractionDigits: 2
			//   }).format(c);			
			// return formattedNumber;
			return c.toFixed(2);
		},
		YYYYMMDD: function(dateobj){
			if(!dateobj) {
				return ''
			} else {
				if(dateobj instanceof Date) {
					return dateobj.getFullYear()+String(dateobj.getMonth()+1).padStart(2,'0')+String(dateobj.getDate()).padStart(2,'0')
				} else {
					return dateobj;
				}
			}
		}


	};
});