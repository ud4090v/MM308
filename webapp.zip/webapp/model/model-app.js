sap.ui.define([
    "sap/ui/model/json/JSONModel",
	],

		/**
		 * Model Constructors.
		 * 
		 * --by_Serge_Breslaw(n88977),@//www.linkedin.com/in/sergebreslaw
		 * 
		 * @memberOf z_ces_rpt.model.models
		 */ 
		
function(JSONModel) {
	"use strict";

	return {
			'id' : "app",
			'owner' : null,
			detailViewModeParamTitle: 1,
			detailViewModeParamValue: 2,			
			'create' : function() {
				return $.Deferred().resolve(new JSONModel({ 
							 cssClass: sap.ui.Device.support.touch ? "sapUiSizeCozy" : "sapUiSizeCompact", 
						     userId:   "",
							 selectedReq:null,
						     pernr:     "",
							 firstName: "",
							 lastName:  "",
							 fullName:  "",
							 email:    "",
							 adminMode: false,
							 editMode: true,
							 sortMode: false,
							 busy : false,
							 delay : 0,
							 layout : "OneColumn",
							 //layout : "TwoColumnsMidExpanded",
							 previousLayout : "",
							 actionButtonsInfo : {
								 midColumn : {
									 fullScreen : false
								 }
							 }							 
							})
						);

			},
			'set' : function(model, owner) {
				this['owner'] = owner || sap.ui.getCore();
				this['owner']['setModel'](model,this.id)
			},
			'setContextData' : function(oData){
				this['get']()['oData'] = oData;
			//	this['get']()['oData']['uplDialog']=false;
				this['get']()['oData']['editMode']=true;
				this['get']()['oData']['sortMode']=false;
				this['get']()['oData'].busy = false;
				this['get']()['oData'].delay = 0;
				this['get']()['oData'].layout = "OneColumn";
				this['get']()['oData'].previousLayout = "";
				this['get']()['oData'].actionButtonsInfo = {
					 midColumn : {
						 fullScreen : false
					 }
				 };							 

				this['get']().refresh(true);
			},			
			'get' : function() {
				return this['owner']['getModel'](this.id);
			},			
			'setSelectedReq': function(oItem){
				this['get']().setProperty("/selectedReq", oItem);
			},
			'getSelectedReq': function(){
				return this['get']().getProperty("/selectedReq");
			},
			'setAppNotBusy': function() {
				this['get']().setProperty("/busy", false);
				this['get']().setProperty("/delay", false);
			},
			'showHasValue' : function() {
				this['get']().setProperty("/showNonBlankOnly", true);
			},
			'showAll' : function() {
				this['get']().setProperty("/showNonBlankOnly", false);
			},
			'showGetMode' : function() {
				return this['get']()['oData'].showNonBlankOnly;
			},			
			'setViewParamTitle' : function() {
				this['get']().setProperty("/viewParamMode", this.detailViewModeParamTitle);
				this.get().refresh(true);
			},
			'setViewParamValue' : function() {
				this['get']().setProperty("/viewParamMode", this.detailViewModeParamValue);
				this.get().refresh(true);
			},
			'isViewParamValue' : function() {
				return (this['get']()['oData'].viewParamMode === this.detailViewModeParamValue);
			},			
			'setLayoutTwoColumns': function() {
				this['get']().setProperty("/layout", "TwoColumnsMidExpanded");
			},
			'setLayoutOneColumn': function() {
				this['get']().setProperty("/layout", "OneColumn");
//				this['get']().setProperty("/layout", "TwoColumnsMidExpanded");
			},
			'toggleFullScreen': function() {
				var _layout = this['get']();
				var bFullScreen = _layout.getProperty("/actionButtonsInfo/midColumn/fullScreen");
				_layout.setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
				if (!bFullScreen) {
					_layout.setProperty("/previousLayout", _layout.getProperty("/layout"));
					_layout.setProperty("/layout", "MidColumnFullScreen");
				} else {
					// reset to previous layout
					_layout.setProperty("/layout", _layout.getProperty("/previousLayout"));
				}				
			},

//			'isUplDialog' : function() {
//				return this['get']()['oData'].uplDialog;
//			},
//			'openUplDialog' : function() {
//				this['get']()['oData'].uplDialog=true;
//				this['get']().refresh(true);
//			},
			'openEditDialog' : function() {
				this['get']()['oData'].editDialog=true;
				this['get']().refresh(true);
			},
			'openEditParameters' : function() {
				this['get']()['oData'].editParam=true;
				this['get']().refresh(true);
			},
			'closeEditParameters' : function() {
				this['get']()['oData'].editParam=false;
				this['get']().refresh(true);
			},
			'getEditParam' : function() {
				return this['get']()['oData'].editParam;
			},			
			'setEdit':function(){
				this['get']()['oData'].editMode=true;
				this['get']().refresh(true);
			},
//			'setEnableSort':function(){
//				this['get']()['oData'].sortMode=true;
//				this['get']().refresh(true);
//			},
//			'setDisableSort':function(){
//				this['get']()['oData'].sortMode=false;
//				this['get']().refresh(true);
//			},			
//			'isSortMode' : function() {
//				return this['get']()['oData'].sortMode;
//			},			
			'setView':function(){
				this['get']()['oData'].editMode=false;
				this['get']().refresh(true);
			},
//			'closeUplDialog' : function() {
//				this['get']()['oData'].uplDialog=false;
//				this['get']().refresh(true);
//			},
			'closeEditDialog' : function() {
				this['get']()['oData'].editDialog=false;
				this['get']().refresh(true);
			},

			
	};
});