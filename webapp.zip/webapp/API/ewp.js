sap.ui.define([], function () {
    'use strict';

    return {
        URL: "https://api-ewp.global.lmco.com",

        Search: {
            fromBackend : function (backendData) {
                var aFiltes = [];
                // var _exempt = (backendData.TestName.startsWith('OR') || backendData.TestName.startsWith('OR') || backendData.TestName.startsWith('RC') || backendData.TestName.startsWith('RR') || backendData.TestName.startsWith('OC'))?true:false;
                
                if( backendData.search ) {
                    aFiltes.push( "Search=" + backendData.searchString );
                }

                if( backendData.NTID ) {
                    aFiltes.push("Search=" + backendData.NTID );
                }

                if( backendData.NTIDList && backendData.NTIDList.length > 0 ) {
                    aFiltes.push("Search=" + backendData.NTIDList.join(",") );
                }


                return "Output=JSON&" + aFiltes.join("&");
            }
        },

        call : function(method, backendData,ignoreError = false, retryCount) {
            self = this;
            var _promise = $.Deferred();
            
            // return new Promise( function(resolve, reject) {
                $.ajax({
                    url         : this.URL + "/PersonService?" + method.fromBackend(backendData),
                    type        : "GET",
                    contentType	: "application/json; charset=utf-8",
                    dataType	: "json",
                    processData	: false,
                    success		: function(data) {
                        _promise.resolve(data); 
                    },
                    error: function(e) {      
						var retries = !retryCount ? 4 : ++retryCount     
                        if (retries > 3) {
                            sap.m.MessageToast.show("EWP Connection Issue, Please Contact System Admin") ;                   
                            
                            _promise.reject("EWP Connection Issue, Please Contact Admin");
                            // return;
                        } else {
                            if(e.statusText!=='abort'){
                                _promise.reject('abort');
                            } else {
                                _self.call(method, backendData,ignoreError, retries).then(function (data) {            //added - Praveen, 9/13
                                    _promise.resolve(data);
                                })
                            }        
                        }
                        // _promise.reject(e);
                    }
                });
                return _promise;
            // });
        },
        call2 : function(method, backendData, fSuccess, fFail, ignoreError = false, retryCount) {
            self = this;
            
            // return new Promise( function(resolve, reject) {
            var request = $.ajax({
                    url         : this.URL + "/PersonService?" + method.fromBackend(backendData),
                    type        : "GET",
                    contentType	: "application/json; charset=utf-8",
                    dataType	: "json",
                    processData	: false,
                    success		: function(data) {
						if (typeof fSuccess === 'function') {
							fSuccess(data);
						}
                    },
                    error: function(e) {  
						var retries = !retryCount ? 2 : ++retryCount     
                        if (retries > 3) {
							if (typeof fFail === 'function') {
								fFail(e);
							}
                            return;
                        } else {
							_self.call2(method, backendData, fSuccess, fFail, ignoreError, retries);
						}
                    }
                });
            // });

        }


    };
});